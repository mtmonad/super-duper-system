/// Application-wide configuration constants.
class AppConfig {
  AppConfig._();

  static const String appName = 'NewsDarpan';
  static const String tagline = 'The Digital Mirror of India';
  static const String appVersion = '1.0.0';

  // API
  static const String apiBaseUrl = 'https://newsdarpan.in/api/mobile/v1/';
  static const String imageBaseUrl = 'https://newsdarpan.in';

  // Headers
  static const String headerAppVersion = 'X-App-Version';
  static const String headerPlatform = 'X-Platform';
  static const String headerAcceptLanguage = 'Accept-Language';

  // Deep link
  static const String deepLinkHost = 'newsdarpan.in';

  // Behavior
  static const Duration searchDebounce = Duration(milliseconds: 400);
  static const int pageSize = 20;
}

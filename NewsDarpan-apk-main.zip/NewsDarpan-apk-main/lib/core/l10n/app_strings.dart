/// Simple string localization for NewsDarpan Reader.
///
/// Supports Hindi (hi) and English (en).
class AppStrings {
  final String language;

  AppStrings(this.language);

  bool get isHindi => language == 'hi';

  String get appName => 'NewsDarpan';
  String get tagline => 'The Digital Mirror of India';

  // Navigation
  String get home => isHindi ? 'होम' : 'Home';
  String get sections => isHindi ? 'अनुभाग' : 'Sections';
  String get search => isHindi ? 'खोजें' : 'Search';
  String get saved => isHindi ? 'सहेजा गया' : 'Saved';
  String get more => isHindi ? 'और' : 'More';

  // Onboarding
  String get selectLanguage => isHindi ? 'भाषा चुनें' : 'Select Language';
  String get hindi => 'हिन्दी';
  String get english => 'English';
  String get selectInterests =>
      isHindi ? 'रुचियाँ चुनें (वैकल्पिक)' : 'Select Interests (Optional)';
  String get getStarted => isHindi ? 'शुरू करें' : 'Get Started';
  String get skip => isHindi ? 'छोड़ें' : 'Skip';
  String get next => isHindi ? 'आगे' : 'Next';

  // Home
  String get latestNews => isHindi ? 'ताज़ा समाचार' : 'Latest News';
  String get pullToRefresh =>
      isHindi ? 'रिफ्रेश करने के लिए खींचें' : 'Pull to refresh';
  String get loadingMore => isHindi ? 'और लोड हो रहा है...' : 'Loading more...';

  // Article
  String get readingTime => isHindi ? 'पढ़ने का समय' : 'Reading time';
  String get minutes => isHindi ? 'मिनट' : 'min';
  String get share => isHindi ? 'शेयर करें' : 'Share';
  String get bookmark => isHindi ? 'सहेजें' : 'Save';
  String get bookmarked => isHindi ? 'सहेजा गया' : 'Saved';
  String get aiGeneratedImage => isHindi ? 'AI जनित छवि' : 'AI Generated Image';

  // Search
  String get searchHint => isHindi ? 'समाचार खोजें...' : 'Search news...';
  String get noResults => isHindi ? 'कोई परिणाम नहीं' : 'No results found';
  String get searchError =>
      isHindi ? 'खोज में त्रुटि हुई' : 'Search encountered an error';

  // Saved
  String get noSavedStories =>
      isHindi ? 'कोई सहेजी गई कहानी नहीं' : 'No saved stories';
  String get savedStoriesHint => isHindi
      ? 'बुकमार्क आइकन टैप करके कहानियां सहेजें'
      : 'Tap the bookmark icon to save stories';

  // Settings
  String get settings => isHindi ? 'सेटिंग्स' : 'Settings';
  String get darkMode => isHindi ? 'डार्क मोड' : 'Dark Mode';
  String get textSize => isHindi ? 'टेक्स्ट का आकार' : 'Text Size';
  String get language_ => isHindi ? 'भाषा' : 'Language';

  // More
  String get authors => isHindi ? 'लेखक' : 'Authors';
  String get legalPages => isHindi ? 'कानूनी पृष्ठ' : 'Legal Pages';

  // Contact
  String get contactUs => isHindi ? 'संपर्क करें' : 'Contact Us';
  String get contactSubtitle =>
      isHindi ? 'हमसे संपर्क करें' : 'Get in touch with us';
  String get phone => isHindi ? 'फ़ोन' : 'Phone';
  String get email => isHindi ? 'ईमेल' : 'Email';
  String get registeredOffice =>
      isHindi ? 'पंजीकृत कार्यालय' : 'Registered Office';
  String get deskEmails => isHindi ? 'डेस्क ईमेल' : 'Desk Emails';
  String get website => isHindi ? 'वेबसाइट' : 'Website';

  // Web Stories
  String get webStories => isHindi ? 'वेब स्टोरीज़' : 'Web Stories';
  String get webStoriesDescription => isHindi
      ? 'NewsDarpan वेब स्टोरीज़ जल्द ही ऐप में उपलब्ध होंगी। अभी वेब पर देखें।'
      : 'NewsDarpan Web Stories coming soon in the app. View them on the web for now.';
  String get viewOnWeb => isHindi ? 'वेब पर देखें' : 'View on Web';
  String get webStoriesComingSoon =>
      isHindi ? 'वेब स्टोरीज़ - जल्द आ रहा है' : 'Web Stories - Coming Soon';
  String get webStoriesHomeHint => isHindi
      ? 'इमर्सिव विज़ुअल स्टोरीज़ के लिए वेब पर देखें'
      : 'View immersive visual stories on the web';

  // States
  String get error => isHindi ? 'त्रुटि' : 'Error';
  String get retry => isHindi ? 'पुनः प्रयास करें' : 'Retry';
  String get loading => isHindi ? 'लोड हो रहा है...' : 'Loading...';
  String get noContent =>
      isHindi ? 'कोई सामग्री उपलब्ध नहीं' : 'No content available';
}

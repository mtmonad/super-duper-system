import 'dart:io';

import 'package:dio/dio.dart';

import '../config/app_config.dart';
import 'api_exception.dart';

/// Dio-based API client for the NewsDarpan mobile API.
///
/// Sends required headers: X-App-Version, X-Platform, Accept-Language.
/// Handles error responses and maps them to [ApiException].
class ApiClient {
  late final Dio _dio;
  final String Function() languageProvider;

  ApiClient({required this.languageProvider}) {
    _dio = Dio(
      BaseOptions(
        baseUrl: AppConfig.apiBaseUrl,
        connectTimeout: const Duration(seconds: 15),
        receiveTimeout: const Duration(seconds: 15),
        headers: {'Accept': 'application/json'},
      ),
    );

    _dio.interceptors.add(
      InterceptorsWrapper(
        onRequest: (options, handler) {
          options.headers[AppConfig.headerAppVersion] = AppConfig.appVersion;
          options.headers[AppConfig.headerPlatform] = Platform.isIOS
              ? 'ios'
              : 'android';
          options.headers[AppConfig.headerAcceptLanguage] = languageProvider();
          handler.next(options);
        },
      ),
    );
  }

  /// GET request returning decoded JSON.
  Future<Map<String, dynamic>> get(
    String path, {
    Map<String, dynamic>? queryParams,
  }) async {
    try {
      final response = await _dio.get<dynamic>(
        path,
        queryParameters: queryParams,
      );
      if (response.data is Map<String, dynamic>) {
        return response.data as Map<String, dynamic>;
      }
      return {'data': response.data};
    } on DioException catch (e) {
      throw _handleDioError(e);
    }
  }

  /// GET request returning a list of JSON objects.
  Future<List<dynamic>> getList(
    String path, {
    Map<String, dynamic>? queryParams,
  }) async {
    try {
      final response = await _dio.get<dynamic>(
        path,
        queryParameters: queryParams,
      );
      if (response.data is List) {
        return response.data as List<dynamic>;
      }
      if (response.data is Map<String, dynamic>) {
        final map = response.data as Map<String, dynamic>;
        // Paginated response with results key
        if (map.containsKey('results')) {
          return map['results'] as List<dynamic>;
        }
      }
      return [];
    } on DioException catch (e) {
      throw _handleDioError(e);
    }
  }

  /// GET request returning full paginated response.
  Future<Map<String, dynamic>> getPaginated(
    String path, {
    Map<String, dynamic>? queryParams,
  }) async {
    try {
      final response = await _dio.get<dynamic>(
        path,
        queryParameters: queryParams,
      );
      if (response.data is Map<String, dynamic>) {
        return response.data as Map<String, dynamic>;
      }
      return {'results': response.data, 'next': null};
    } on DioException catch (e) {
      throw _handleDioError(e);
    }
  }

  ApiException _handleDioError(DioException e) {
    switch (e.type) {
      case DioExceptionType.connectionTimeout:
      case DioExceptionType.sendTimeout:
      case DioExceptionType.receiveTimeout:
        return ApiException.timeout();
      case DioExceptionType.connectionError:
        return ApiException.network();
      case DioExceptionType.badResponse:
        final statusCode = e.response?.statusCode ?? 0;
        final data = e.response?.data;
        if (data is Map<String, dynamic>) {
          return ApiException.fromResponse(data, statusCode);
        }
        return ApiException(
          code: 'http_$statusCode',
          message: 'Server returned status $statusCode',
          statusCode: statusCode,
        );
      default:
        return ApiException.unknown(e.message);
    }
  }
}

/// Structured API exception for the NewsDarpan mobile API.
class ApiException implements Exception {
  final String code;
  final String message;
  final int? statusCode;
  final String? requestId;

  const ApiException({
    required this.code,
    required this.message,
    this.statusCode,
    this.requestId,
  });

  factory ApiException.fromResponse(Map<String, dynamic> json, int status) {
    final error = json['error'] as Map<String, dynamic>? ?? json;
    return ApiException(
      code: error['code']?.toString() ?? 'unknown_error',
      message: error['message']?.toString() ?? 'An unexpected error occurred.',
      statusCode: status,
      requestId: error['request_id']?.toString(),
    );
  }

  factory ApiException.network() => const ApiException(
    code: 'network_error',
    message: 'Unable to connect. Please check your internet connection.',
  );

  factory ApiException.timeout() => const ApiException(
    code: 'timeout',
    message: 'Request timed out. Please try again.',
  );

  factory ApiException.unknown([String? detail]) => ApiException(
    code: 'unknown_error',
    message: detail ?? 'An unexpected error occurred.',
  );

  @override
  String toString() => 'ApiException($code): $message';
}

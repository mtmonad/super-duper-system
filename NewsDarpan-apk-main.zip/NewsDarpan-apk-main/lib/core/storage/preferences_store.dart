import 'package:shared_preferences/shared_preferences.dart';

/// Wraps SharedPreferences for typed access to user preferences.
class PreferencesStore {
  final SharedPreferences? _prefs;

  PreferencesStore(SharedPreferences prefs) : _prefs = prefs;

  PreferencesStore.empty() : _prefs = null;

  // Keys
  static const _keyOnboarding = 'onboarding_complete';
  static const _keyLanguage = 'language';
  static const _keyDarkMode = 'dark_mode';
  static const _keyTextScale = 'text_scale';
  static const _keyBookmarks = 'bookmarks';

  bool get onboardingComplete => _prefs?.getBool(_keyOnboarding) ?? false;
  String get language => _prefs?.getString(_keyLanguage) ?? 'hi';
  bool get isDarkMode => _prefs?.getBool(_keyDarkMode) ?? false;
  double get textScale => _prefs?.getDouble(_keyTextScale) ?? 1.0;
  List<String> get bookmarkedIds => _prefs?.getStringList(_keyBookmarks) ?? [];

  void setOnboardingComplete(bool value) {
    _prefs?.setBool(_keyOnboarding, value);
  }

  void setLanguage(String lang) {
    _prefs?.setString(_keyLanguage, lang);
  }

  void setDarkMode(bool value) {
    _prefs?.setBool(_keyDarkMode, value);
  }

  void setTextScale(double value) {
    _prefs?.setDouble(_keyTextScale, value);
  }

  void setBookmarks(List<String> ids) {
    _prefs?.setStringList(_keyBookmarks, ids);
  }
}

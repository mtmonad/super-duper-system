import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../app/providers.dart';
import '../../core/l10n/app_strings.dart';
import '../../shared/widgets/states.dart';
import '../../shared/widgets/story_card.dart';

/// Screen displaying bookmarked stories saved locally.
class SavedScreen extends ConsumerWidget {
  const SavedScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final appState = ref.watch(appStateProvider);
    final strings = AppStrings(appState.language);
    final bookmarks = ref.watch(bookmarksProvider);
    final savedAsync = ref.watch(savedStoriesProvider);

    if (bookmarks.isEmpty) {
      return EmptyState(
        icon: Icons.bookmark_outline,
        title: strings.noSavedStories,
        subtitle: strings.savedStoriesHint,
      );
    }

    return savedAsync.when(
      loading: () => LoadingState(message: strings.loading),
      error: (e, _) => ErrorState(
        message: e.toString(),
        onRetry: () => ref.invalidate(savedStoriesProvider),
      ),
      data: (stories) {
        if (stories.isEmpty) {
          return EmptyState(
            icon: Icons.bookmark_outline,
            title: strings.noSavedStories,
            subtitle: strings.savedStoriesHint,
          );
        }
        return ListView.builder(
          itemCount: stories.length,
          itemBuilder: (context, index) {
            final story = stories[index];
            return StoryCard(
              story: story,
              isBookmarked: true,
              onTap: () => context.push('/article/${story.id}'),
              onBookmark: () =>
                  ref.read(bookmarksProvider.notifier).toggle(story.id),
            );
          },
        );
      },
    );
  }
}

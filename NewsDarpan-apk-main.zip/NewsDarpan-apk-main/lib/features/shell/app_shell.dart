import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../app/providers.dart';
import '../../core/l10n/app_strings.dart';

/// The main app shell with bottom navigation and branded header.
class AppShell extends ConsumerWidget {
  final Widget child;

  const AppShell({super.key, required this.child});

  static const _destinations = [
    '/home',
    '/sections',
    '/search',
    '/saved',
    '/more',
  ];

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final appState = ref.watch(appStateProvider);
    final strings = AppStrings(appState.language);
    final currentPath = GoRouterState.of(context).uri.path;
    final currentIndex = _destinations.indexWhere(
      (d) => currentPath.startsWith(d),
    );

    return Scaffold(
      appBar: AppBar(
        title: Semantics(
          label: 'NewsDarpan Logo',
          child: Image.asset(
            'assets/branding/logo-header-transparent.png',
            height: 36,
            semanticLabel: 'NewsDarpan',
          ),
        ),
        actions: [
          // Language toggle HI/EN
          TextButton(
            onPressed: () {
              final newLang = appState.language == 'hi' ? 'en' : 'hi';
              ref.read(appStateProvider.notifier).setLanguage(newLang);
            },
            child: Text(
              appState.language == 'hi' ? 'EN' : 'HI',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: Theme.of(context).colorScheme.primary,
              ),
              semanticsLabel: appState.language == 'hi'
                  ? 'Switch to English'
                  : 'Switch to Hindi',
            ),
          ),
        ],
      ),
      body: usePreviewData
          ? Banner(
              message: 'PREVIEW',
              location: BannerLocation.topEnd,
              child: child,
            )
          : child,
      bottomNavigationBar: NavigationBar(
        selectedIndex: currentIndex < 0 ? 0 : currentIndex,
        onDestinationSelected: (index) {
          context.go(_destinations[index]);
        },
        destinations: [
          NavigationDestination(
            icon: const Icon(Icons.home_outlined),
            selectedIcon: const Icon(Icons.home),
            label: strings.home,
          ),
          NavigationDestination(
            icon: const Icon(Icons.category_outlined),
            selectedIcon: const Icon(Icons.category),
            label: strings.sections,
          ),
          NavigationDestination(
            icon: const Icon(Icons.search),
            selectedIcon: const Icon(Icons.search),
            label: strings.search,
          ),
          NavigationDestination(
            icon: const Icon(Icons.bookmark_outline),
            selectedIcon: const Icon(Icons.bookmark),
            label: strings.saved,
          ),
          NavigationDestination(
            icon: const Icon(Icons.more_horiz),
            selectedIcon: const Icon(Icons.more_horiz),
            label: strings.more,
          ),
        ],
      ),
    );
  }
}

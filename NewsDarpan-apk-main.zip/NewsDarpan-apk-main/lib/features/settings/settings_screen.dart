import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../app/providers.dart';
import '../../core/l10n/app_strings.dart';

/// Settings screen: theme toggle, text scale, language selection.
class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final appState = ref.watch(appStateProvider);
    final strings = AppStrings(appState.language);

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => context.pop(),
          tooltip: 'Back',
        ),
        title: Text(strings.settings),
      ),
      body: ListView(
        children: [
          // Theme toggle
          SwitchListTile(
            secondary: Icon(
              appState.isDarkMode ? Icons.dark_mode : Icons.light_mode,
            ),
            title: Text(strings.darkMode),
            value: appState.isDarkMode,
            onChanged: (_) {
              ref.read(appStateProvider.notifier).toggleTheme();
            },
          ),
          const Divider(height: 1),

          // Text scale
          ListTile(
            leading: const Icon(Icons.text_fields),
            title: Text(strings.textSize),
            subtitle: Slider(
              min: 0.8,
              max: 1.5,
              divisions: 7,
              value: appState.textScale,
              label: '${(appState.textScale * 100).round()}%',
              onChanged: (value) {
                ref.read(appStateProvider.notifier).setTextScale(value);
              },
            ),
          ),
          const Divider(height: 1),

          // Language selection
          ListTile(
            leading: const Icon(Icons.language),
            title: Text(strings.language_),
            trailing: SegmentedButton<String>(
              segments: [
                ButtonSegment(value: 'hi', label: Text(strings.hindi)),
                ButtonSegment(value: 'en', label: Text(strings.english)),
              ],
              selected: {appState.language},
              onSelectionChanged: (selection) {
                ref
                    .read(appStateProvider.notifier)
                    .setLanguage(selection.first);
              },
            ),
          ),
        ],
      ),
    );
  }
}

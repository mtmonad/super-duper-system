import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../app/providers.dart';
import '../../core/config/app_config.dart';
import '../../core/l10n/app_strings.dart';
import '../../core/network/api_exception.dart';
import '../../domain/models/story.dart';
import '../../shared/widgets/states.dart';
import '../../shared/widgets/story_card.dart';

/// Search screen with 400ms debounce.
class SearchScreen extends ConsumerStatefulWidget {
  const SearchScreen({super.key});

  @override
  ConsumerState<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends ConsumerState<SearchScreen> {
  final _controller = TextEditingController();
  Timer? _debounce;
  List<Story> _results = [];
  bool _isLoading = false;
  String? _error;
  bool _hasSearched = false;

  @override
  void dispose() {
    _debounce?.cancel();
    _controller.dispose();
    super.dispose();
  }

  void _onQueryChanged(String query) {
    _debounce?.cancel();
    if (query.trim().isEmpty) {
      setState(() {
        _results = [];
        _isLoading = false;
        _error = null;
        _hasSearched = false;
      });
      return;
    }
    _debounce = Timer(AppConfig.searchDebounce, () {
      _performSearch(query.trim());
    });
  }

  Future<void> _performSearch(String query) async {
    setState(() {
      _isLoading = true;
      _error = null;
      _hasSearched = true;
    });
    try {
      final repo = ref.read(newsRepositoryProvider);
      final lang = ref.read(appStateProvider).language;
      final result = await repo.searchStories(query: query, language: lang);
      if (mounted) {
        setState(() {
          _results = result.items;
          _isLoading = false;
        });
      }
    } on ApiException catch (e) {
      if (mounted) {
        setState(() {
          _error = e.message;
          _isLoading = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _error = e.toString();
          _isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final appState = ref.watch(appStateProvider);
    final strings = AppStrings(appState.language);
    final bookmarks = ref.watch(bookmarksProvider);

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: TextField(
            controller: _controller,
            onChanged: _onQueryChanged,
            decoration: InputDecoration(
              hintText: strings.searchHint,
              prefixIcon: const Icon(Icons.search),
              suffixIcon: _controller.text.isNotEmpty
                  ? IconButton(
                      icon: const Icon(Icons.clear),
                      onPressed: () {
                        _controller.clear();
                        _onQueryChanged('');
                      },
                    )
                  : null,
            ),
            textInputAction: TextInputAction.search,
          ),
        ),
        Expanded(child: _buildBody(strings, bookmarks)),
      ],
    );
  }

  Widget _buildBody(AppStrings strings, Set<String> bookmarks) {
    if (_isLoading) {
      return const LoadingState();
    }

    if (_error != null) {
      return ErrorState(
        message: strings.searchError,
        onRetry: () => _performSearch(_controller.text.trim()),
      );
    }

    if (!_hasSearched) {
      return EmptyState(icon: Icons.search, title: strings.searchHint);
    }

    if (_results.isEmpty) {
      return EmptyState(icon: Icons.search_off, title: strings.noResults);
    }

    return ListView.builder(
      itemCount: _results.length,
      itemBuilder: (context, index) {
        final story = _results[index];
        return StoryCard(
          story: story,
          isBookmarked: bookmarks.contains(story.id),
          onTap: () => context.push('/article/${story.id}'),
          onBookmark: () =>
              ref.read(bookmarksProvider.notifier).toggle(story.id),
        );
      },
    );
  }
}

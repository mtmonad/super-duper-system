import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../app/providers.dart';
import '../../core/l10n/app_strings.dart';

/// Web Stories placeholder screen with NewsDarpan branding.
class WebStoriesScreen extends ConsumerWidget {
  const WebStoriesScreen({super.key});

  static const _webStoriesUrl = 'https://newsdarpan.in/web-stories/';

  Future<void> _openWebStories() async {
    final uri = Uri.parse(_webStoriesUrl);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.inAppBrowserView);
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final appState = ref.watch(appStateProvider);
    final strings = AppStrings(appState.language);
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(title: Text(strings.webStories)),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset(
                'assets/branding/logo-header-transparent.png',
                height: 48,
                semanticLabel: 'NewsDarpan',
              ),
              const SizedBox(height: 24),
              Icon(
                Icons.amp_stories,
                size: 64,
                color: theme.colorScheme.primary,
              ),
              const SizedBox(height: 16),
              Text(
                strings.webStories,
                style: theme.textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                strings.webStoriesDescription,
                textAlign: TextAlign.center,
                style: theme.textTheme.bodyMedium?.copyWith(
                  color: theme.colorScheme.onSurfaceVariant,
                ),
              ),
              const SizedBox(height: 32),
              FilledButton.icon(
                onPressed: _openWebStories,
                icon: const Icon(Icons.open_in_browser),
                label: Text(strings.viewOnWeb),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

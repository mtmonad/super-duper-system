import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../app/providers.dart';
import '../../core/l10n/app_strings.dart';
import '../../core/network/api_exception.dart';
import '../../domain/models/feed.dart';
import '../../shared/widgets/states.dart';

/// Provider that fetches sections from bootstrap.
final _sectionsProvider = FutureProvider<List<Section>>((ref) async {
  final repo = ref.watch(newsRepositoryProvider);
  final bootstrap = await repo.getBootstrap();
  return bootstrap.sections;
});

/// Lists all available sections from the bootstrap API.
class SectionsScreen extends ConsumerWidget {
  const SectionsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final sectionsAsync = ref.watch(_sectionsProvider);
    final appState = ref.watch(appStateProvider);
    final strings = AppStrings(appState.language);

    return sectionsAsync.when(
      loading: () => LoadingState(message: strings.loading),
      error: (error, _) => ErrorState(
        message: error is ApiException ? error.message : error.toString(),
        onRetry: () => ref.invalidate(_sectionsProvider),
      ),
      data: (sections) {
        if (sections.isEmpty) {
          return EmptyState(
            icon: Icons.category_outlined,
            title: strings.noContent,
          );
        }
        return ListView.builder(
          padding: const EdgeInsets.symmetric(vertical: 8),
          itemCount: sections.length,
          itemBuilder: (context, index) {
            final section = sections[index];
            return ListTile(
              contentPadding: const EdgeInsets.symmetric(
                horizontal: 24,
                vertical: 4,
              ),
              leading: CircleAvatar(
                backgroundColor: Theme.of(
                  context,
                ).colorScheme.primary.withValues(alpha: 0.1),
                child: Text(
                  section.name.isNotEmpty ? section.name[0] : '?',
                  style: TextStyle(
                    color: Theme.of(context).colorScheme.primary,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              title: Text(
                section.name,
                style: Theme.of(context).textTheme.titleLarge,
              ),
              trailing: const Icon(Icons.chevron_right),
              onTap: () {
                // Navigate to section detail/stories (future enhancement)
                // For now shows a snackbar
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('${section.name} section'),
                    duration: const Duration(seconds: 1),
                  ),
                );
              },
            );
          },
        );
      },
    );
  }
}

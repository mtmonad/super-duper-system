import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../app/providers.dart';
import '../../core/config/app_config.dart';
import '../../core/l10n/app_strings.dart';
import '../../core/network/api_exception.dart';
import '../../domain/models/feed.dart';

/// Provider for legal pages from bootstrap.
final _legalPagesProvider = FutureProvider<List<LegalPageRef>>((ref) async {
  final repo = ref.watch(newsRepositoryProvider);
  final bootstrap = await repo.getBootstrap();
  return bootstrap.legalPages;
});

/// More screen: Authors, Settings, Legal pages, app info.
class MoreScreen extends ConsumerWidget {
  const MoreScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final appState = ref.watch(appStateProvider);
    final strings = AppStrings(appState.language);
    final legalAsync = ref.watch(_legalPagesProvider);
    final theme = Theme.of(context);

    return ListView(
      children: [
        // Web Stories
        ListTile(
          leading: const Icon(Icons.amp_stories),
          title: Text(strings.webStories),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => context.push('/web-stories'),
        ),
        const Divider(height: 1),

        // Authors
        ListTile(
          leading: const Icon(Icons.people_outline),
          title: Text(strings.authors),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => context.push('/author/all'),
        ),
        const Divider(height: 1),

        // Settings
        ListTile(
          leading: const Icon(Icons.settings_outlined),
          title: Text(strings.settings),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => context.push('/settings'),
        ),
        const Divider(height: 1),

        // Contact Us
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 24, 16, 8),
          child: Text(
            strings.contactUs,
            style: theme.textTheme.titleMedium?.copyWith(
              color: theme.colorScheme.primary,
            ),
          ),
        ),
        ListTile(
          leading: Icon(Icons.phone, color: theme.colorScheme.primary),
          title: Text(strings.contactUs),
          subtitle: const Text('+91-98330 00048'),
          trailing: Icon(Icons.email, color: theme.colorScheme.primary),
          onTap: () => context.push('/contact'),
        ),
        const Divider(height: 1),

        // Legal pages section
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 24, 16, 8),
          child: Text(
            strings.legalPages,
            style: theme.textTheme.titleMedium?.copyWith(
              color: theme.colorScheme.primary,
            ),
          ),
        ),
        legalAsync.when(
          loading: () => const ListTile(title: LinearProgressIndicator()),
          error: (e, _) => ListTile(
            title: Text(
              e is ApiException ? e.message : 'Unable to load legal pages',
              style: theme.textTheme.bodySmall,
            ),
          ),
          data: (pages) => Column(
            children: pages
                .map(
                  (page) => ListTile(
                    leading: const Icon(Icons.description_outlined),
                    title: Text(page.title),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => context.push('/legal/${page.slug}'),
                  ),
                )
                .toList(),
          ),
        ),
        const Divider(height: 1),

        // App info
        Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              Image.asset(
                'assets/branding/logo-header-transparent.png',
                height: 32,
                semanticLabel: 'NewsDarpan',
              ),
              const SizedBox(height: 8),
              const Text(
                'The Digital Mirror of India',
                style: TextStyle(fontStyle: FontStyle.italic, fontSize: 12),
              ),
              const SizedBox(height: 4),
              Text(
                'Version ${AppConfig.appVersion}',
                style: theme.textTheme.bodySmall,
              ),
            ],
          ),
        ),
      ],
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../app/providers.dart';
import '../../core/l10n/app_strings.dart';
import '../../core/network/api_exception.dart';
import '../../domain/models/story.dart';
import '../../shared/widgets/states.dart';
import '../../shared/widgets/story_card.dart';

/// Home feed provider with cursor-based pagination.
final _homeFeedProvider =
    StateNotifierProvider<_HomeFeedNotifier, _HomeFeedState>((ref) {
      return _HomeFeedNotifier(ref);
    });

class _HomeFeedState {
  final List<Story> stories;
  final bool isLoading;
  final bool isLoadingMore;
  final String? error;
  final String? nextCursor;

  const _HomeFeedState({
    this.stories = const [],
    this.isLoading = true,
    this.isLoadingMore = false,
    this.error,
    this.nextCursor,
  });

  _HomeFeedState copyWith({
    List<Story>? stories,
    bool? isLoading,
    bool? isLoadingMore,
    String? error,
    String? nextCursor,
    bool clearError = false,
  }) {
    return _HomeFeedState(
      stories: stories ?? this.stories,
      isLoading: isLoading ?? this.isLoading,
      isLoadingMore: isLoadingMore ?? this.isLoadingMore,
      error: clearError ? null : (error ?? this.error),
      nextCursor: nextCursor ?? this.nextCursor,
    );
  }
}

class _HomeFeedNotifier extends StateNotifier<_HomeFeedState> {
  final Ref _ref;

  _HomeFeedNotifier(this._ref) : super(const _HomeFeedState()) {
    loadStories();
  }

  Future<void> loadStories() async {
    state = state.copyWith(isLoading: true, clearError: true);
    try {
      final repo = _ref.read(newsRepositoryProvider);
      final lang = _ref.read(appStateProvider).language;
      final result = await repo.getStories(language: lang);
      state = _HomeFeedState(
        stories: result.items,
        isLoading: false,
        nextCursor: result.nextCursor,
      );
    } on ApiException catch (e) {
      state = state.copyWith(isLoading: false, error: e.message);
    } catch (e) {
      state = state.copyWith(isLoading: false, error: e.toString());
    }
  }

  Future<void> loadMore() async {
    if (state.isLoadingMore || state.nextCursor == null) return;
    state = state.copyWith(isLoadingMore: true);
    try {
      final repo = _ref.read(newsRepositoryProvider);
      final lang = _ref.read(appStateProvider).language;
      final result = await repo.getStories(
        language: lang,
        cursor: state.nextCursor,
      );
      state = state.copyWith(
        stories: [...state.stories, ...result.items],
        isLoadingMore: false,
        nextCursor: result.nextCursor,
      );
    } catch (_) {
      state = state.copyWith(isLoadingMore: false);
    }
  }
}

/// Home screen showing latest stories with pull-to-refresh and pagination.
class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final feedState = ref.watch(_homeFeedProvider);
    final appState = ref.watch(appStateProvider);
    final strings = AppStrings(appState.language);
    final bookmarks = ref.watch(bookmarksProvider);

    if (feedState.isLoading) {
      return LoadingState(message: strings.loading);
    }

    if (feedState.error != null && feedState.stories.isEmpty) {
      return ErrorState(
        message: feedState.error!,
        onRetry: () => ref.read(_homeFeedProvider.notifier).loadStories(),
      );
    }

    if (feedState.stories.isEmpty) {
      return EmptyState(icon: Icons.newspaper, title: strings.noContent);
    }

    return RefreshIndicator(
      onRefresh: () => ref.read(_homeFeedProvider.notifier).loadStories(),
      child: NotificationListener<ScrollNotification>(
        onNotification: (notification) {
          if (notification is ScrollEndNotification &&
              notification.metrics.extentAfter < 200) {
            ref.read(_homeFeedProvider.notifier).loadMore();
          }
          return false;
        },
        child: ListView.builder(
          itemCount:
              feedState.stories.length + (feedState.isLoadingMore ? 1 : 0) + 1,
          itemBuilder: (context, index) {
            // Web Stories card at the end
            if (index ==
                feedState.stories.length + (feedState.isLoadingMore ? 1 : 0)) {
              return _WebStoriesCard(strings: strings);
            }
            if (index == feedState.stories.length) {
              return Padding(
                padding: const EdgeInsets.all(16),
                child: Center(child: Text(strings.loadingMore)),
              );
            }
            final story = feedState.stories[index];
            return StoryCard(
              story: story,
              isBookmarked: bookmarks.contains(story.id),
              onTap: () => context.push('/article/${story.id}'),
              onBookmark: () =>
                  ref.read(bookmarksProvider.notifier).toggle(story.id),
            );
          },
        ),
      ),
    );
  }
}

class _WebStoriesCard extends StatelessWidget {
  final AppStrings strings;

  const _WebStoriesCard({required this.strings});

  Future<void> _openWebStories() async {
    final uri = Uri.parse('https://newsdarpan.in/web-stories/');
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.inAppBrowserView);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(Icons.amp_stories, color: theme.colorScheme.primary),
                  const SizedBox(width: 8),
                  Text(
                    strings.webStoriesComingSoon,
                    style: theme.textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Text(
                strings.webStoriesHomeHint,
                style: theme.textTheme.bodyMedium?.copyWith(
                  color: theme.colorScheme.onSurfaceVariant,
                ),
              ),
              const SizedBox(height: 12),
              FilledButton.icon(
                onPressed: _openWebStories,
                icon: const Icon(Icons.open_in_browser),
                label: Text(strings.viewOnWeb),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

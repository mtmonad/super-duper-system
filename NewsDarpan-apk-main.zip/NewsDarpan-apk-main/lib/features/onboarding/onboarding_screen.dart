import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../app/providers.dart';
import '../../core/l10n/app_strings.dart';

/// First-run onboarding: language selection (HI/EN) and optional interests.
class OnboardingScreen extends ConsumerStatefulWidget {
  const OnboardingScreen({super.key});

  @override
  ConsumerState<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends ConsumerState<OnboardingScreen> {
  int _page = 0;
  String _selectedLanguage = 'hi';
  final Set<String> _selectedInterests = {};

  static const _interests = [
    'National',
    'International',
    'Sports',
    'Entertainment',
    'Science',
    'Business',
    'Technology',
    'Health',
  ];

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final strings = AppStrings(_selectedLanguage);

    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              // Logo
              Padding(
                padding: const EdgeInsets.only(top: 40, bottom: 32),
                child: Image.asset(
                  'assets/branding/logo-header-400x120.png',
                  height: 60,
                  semanticLabel: 'NewsDarpan',
                ),
              ),
              const Text(
                'The Digital Mirror of India',
                style: TextStyle(fontStyle: FontStyle.italic, fontSize: 14),
              ),
              const SizedBox(height: 48),
              Expanded(
                child: _page == 0
                    ? _buildLanguagePage(theme, strings)
                    : _buildInterestsPage(theme, strings),
              ),
              // Bottom actions
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  if (_page == 1)
                    TextButton(
                      onPressed: _completeOnboarding,
                      child: Text(strings.skip),
                    )
                  else
                    const SizedBox.shrink(),
                  ElevatedButton(
                    onPressed: _page == 0
                        ? _goToInterests
                        : _completeOnboarding,
                    child: Text(_page == 0 ? strings.next : strings.getStarted),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildLanguagePage(ThemeData theme, AppStrings strings) {
    return Column(
      children: [
        Text(strings.selectLanguage, style: theme.textTheme.headlineMedium),
        const SizedBox(height: 32),
        _LanguageTile(
          label: 'हिन्दी',
          subtitle: 'Hindi',
          selected: _selectedLanguage == 'hi',
          onTap: () => setState(() => _selectedLanguage = 'hi'),
        ),
        const SizedBox(height: 16),
        _LanguageTile(
          label: 'English',
          subtitle: 'अंग्रेज़ी',
          selected: _selectedLanguage == 'en',
          onTap: () => setState(() => _selectedLanguage = 'en'),
        ),
      ],
    );
  }

  Widget _buildInterestsPage(ThemeData theme, AppStrings strings) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(strings.selectInterests, style: theme.textTheme.headlineMedium),
        const SizedBox(height: 24),
        Expanded(
          child: Wrap(
            spacing: 8,
            runSpacing: 8,
            children: _interests.map((interest) {
              final selected = _selectedInterests.contains(interest);
              return FilterChip(
                label: Text(interest),
                selected: selected,
                onSelected: (v) {
                  setState(() {
                    if (v) {
                      _selectedInterests.add(interest);
                    } else {
                      _selectedInterests.remove(interest);
                    }
                  });
                },
              );
            }).toList(),
          ),
        ),
      ],
    );
  }

  void _goToInterests() {
    ref.read(appStateProvider.notifier).setLanguage(_selectedLanguage);
    setState(() => _page = 1);
  }

  void _completeOnboarding() {
    ref.read(appStateProvider.notifier).setLanguage(_selectedLanguage);
    ref.read(appStateProvider.notifier).completeOnboarding();
    context.go('/home');
  }
}

class _LanguageTile extends StatelessWidget {
  final String label;
  final String subtitle;
  final bool selected;
  final VoidCallback onTap;

  const _LanguageTile({
    required this.label,
    required this.subtitle,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Material(
      color: selected
          ? theme.colorScheme.primary.withValues(alpha: 0.1)
          : theme.colorScheme.surfaceContainerHighest,
      borderRadius: BorderRadius.circular(12),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: selected ? theme.colorScheme.primary : Colors.transparent,
              width: 2,
            ),
          ),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(label, style: theme.textTheme.titleLarge),
                    Text(subtitle, style: theme.textTheme.bodySmall),
                  ],
                ),
              ),
              if (selected)
                Icon(Icons.check_circle, color: theme.colorScheme.primary),
            ],
          ),
        ),
      ),
    );
  }
}

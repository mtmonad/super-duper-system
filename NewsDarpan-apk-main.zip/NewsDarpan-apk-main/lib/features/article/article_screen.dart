import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import 'package:share_plus/share_plus.dart';

import '../../app/providers.dart';
import '../../core/l10n/app_strings.dart';
import '../../core/network/api_exception.dart';
import '../../domain/models/story.dart';
import '../../shared/widgets/states.dart';

/// Article detail screen with full story rendering.
class ArticleScreen extends ConsumerStatefulWidget {
  final String storyId;

  const ArticleScreen({super.key, required this.storyId});

  @override
  ConsumerState<ArticleScreen> createState() => _ArticleScreenState();
}

class _ArticleScreenState extends ConsumerState<ArticleScreen> {
  Story? _story;
  bool _isLoading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadStory();
  }

  Future<void> _loadStory() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });
    try {
      final repo = ref.read(newsRepositoryProvider);
      final story = await repo.getStoryDetail(widget.storyId);
      if (mounted) {
        setState(() {
          _story = story;
          _isLoading = false;
        });
      }
    } on ApiException catch (e) {
      if (mounted) {
        setState(() {
          _error = e.message;
          _isLoading = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _error = e.toString();
          _isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final appState = ref.watch(appStateProvider);
    final strings = AppStrings(appState.language);
    final bookmarks = ref.watch(bookmarksProvider);

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => context.pop(),
          tooltip: 'Back',
        ),
        actions: [
          if (_story != null) ...[
            IconButton(
              icon: Icon(
                bookmarks.contains(widget.storyId)
                    ? Icons.bookmark
                    : Icons.bookmark_border,
              ),
              onPressed: () =>
                  ref.read(bookmarksProvider.notifier).toggle(widget.storyId),
              tooltip: strings.bookmark,
            ),
            IconButton(
              icon: const Icon(Icons.share),
              onPressed: () => _shareStory(),
              tooltip: strings.share,
            ),
          ],
        ],
      ),
      body: _buildBody(strings),
    );
  }

  Widget _buildBody(AppStrings strings) {
    if (_isLoading) return LoadingState(message: strings.loading);
    if (_error != null) {
      return ErrorState(message: _error!, onRetry: _loadStory);
    }
    if (_story == null) return EmptyState(title: strings.noContent);

    final story = _story!;
    final theme = Theme.of(context);
    final dateFormat = DateFormat.yMMMd().add_Hm();

    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Section badge
          if (story.section != null)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 4,
                ),
                decoration: BoxDecoration(
                  color: theme.colorScheme.primary.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(4),
                ),
                child: Text(
                  story.section!.name,
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: theme.colorScheme.primary,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),

          // Headline
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Text(story.title, style: theme.textTheme.headlineLarge),
          ),

          // Dek
          if (story.dek != null && story.dek!.isNotEmpty)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
              child: Text(
                story.dek!,
                style: theme.textTheme.bodyLarge?.copyWith(
                  color: theme.textTheme.bodySmall?.color,
                ),
              ),
            ),

          // Author row
          if (story.author != null)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
              child: InkWell(
                onTap: () {
                  if (story.author!.authorSlug != null) {
                    context.push('/author/${story.author!.authorSlug}');
                  }
                },
                borderRadius: BorderRadius.circular(8),
                child: Row(
                  children: [
                    CircleAvatar(
                      radius: 20,
                      backgroundImage:
                          story.author!.avatarUrl != null &&
                              story.author!.avatarUrl!.isNotEmpty
                          ? CachedNetworkImageProvider(story.author!.avatarUrl!)
                          : null,
                      child:
                          story.author!.avatarUrl == null ||
                              story.author!.avatarUrl!.isEmpty
                          ? Text(
                              story.author!.fullName.isNotEmpty
                                  ? story.author!.fullName[0]
                                  : '?',
                            )
                          : null,
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            story.author!.fullName,
                            style: theme.textTheme.titleMedium,
                          ),
                          if (story.author!.title != null)
                            Text(
                              story.author!.title!,
                              style: theme.textTheme.bodySmall,
                            ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),

          // Timestamps + reading time
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
            child: Wrap(
              spacing: 16,
              runSpacing: 4,
              children: [
                if (story.publishedAt != null)
                  Text(
                    dateFormat.format(story.publishedAt!.toLocal()),
                    style: theme.textTheme.bodySmall,
                  ),
                if (story.updatedAt != null &&
                    story.updatedAt != story.publishedAt)
                  Text(
                    'Updated: ${dateFormat.format(story.updatedAt!.toLocal())}',
                    style: theme.textTheme.bodySmall,
                  ),
                if (story.readingTimeMinutes != null)
                  Text(
                    '${story.readingTimeMinutes} ${strings.minutes} ${strings.readingTime}',
                    style: theme.textTheme.bodySmall,
                  ),
              ],
            ),
          ),

          // Hero image
          if (story.image != null && story.image!.url.isNotEmpty)
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                AspectRatio(
                  aspectRatio: 16 / 9,
                  child: CachedNetworkImage(
                    imageUrl: story.image!.url,
                    fit: BoxFit.cover,
                    placeholder: (context, url) => Container(
                      color: theme.colorScheme.surfaceContainerHighest,
                    ),
                    errorWidget: (context, url, error) => Container(
                      color: theme.colorScheme.surfaceContainerHighest,
                      child: const Center(child: Icon(Icons.broken_image)),
                    ),
                  ),
                ),
                // Caption + credit + AI badge
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 8,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      if (story.image!.isAiGenerated)
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 6,
                            vertical: 2,
                          ),
                          margin: const EdgeInsets.only(bottom: 4),
                          decoration: BoxDecoration(
                            color: Colors.amber.shade100,
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: Text(
                            strings.aiGeneratedImage,
                            style: theme.textTheme.bodySmall?.copyWith(
                              fontWeight: FontWeight.w600,
                              color: Colors.brown.shade800,
                            ),
                          ),
                        ),
                      if (story.image!.caption != null)
                        Text(
                          story.image!.caption!,
                          style: theme.textTheme.bodySmall,
                        ),
                      if (story.image!.credit != null)
                        Text(
                          story.image!.credit!,
                          style: theme.textTheme.bodySmall?.copyWith(
                            fontStyle: FontStyle.italic,
                          ),
                        ),
                    ],
                  ),
                ),
              ],
            ),

          // Body content
          if (story.bodyBlocks != null && story.bodyBlocks!.isNotEmpty)
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: story.bodyBlocks!.map(_buildBlock).toList(),
              ),
            )
          else if (story.bodyHtml != null)
            Padding(
              padding: const EdgeInsets.all(16),
              child: Text(
                // Simple text rendering - strip tags
                story.bodyHtml!.replaceAll(RegExp(r'<[^>]*>'), ''),
                style: theme.textTheme.bodyLarge,
              ),
            ),

          const SizedBox(height: 48),
        ],
      ),
    );
  }

  Widget _buildBlock(BodyBlock block) {
    final theme = Theme.of(context);
    switch (block.type) {
      case 'heading':
        return Padding(
          padding: const EdgeInsets.only(top: 16, bottom: 8),
          child: Text(block.text ?? '', style: theme.textTheme.headlineSmall),
        );
      case 'image':
        return Padding(
          padding: const EdgeInsets.symmetric(vertical: 12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (block.url != null)
                ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: CachedNetworkImage(
                    imageUrl: block.url!,
                    fit: BoxFit.cover,
                    width: double.infinity,
                  ),
                ),
              if (block.caption != null)
                Padding(
                  padding: const EdgeInsets.only(top: 4),
                  child: Text(block.caption!, style: theme.textTheme.bodySmall),
                ),
            ],
          ),
        );
      case 'list':
        return Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: (block.items ?? [])
                .map(
                  (item) => Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('  \u2022  '),
                        Expanded(
                          child: Text(item, style: theme.textTheme.bodyLarge),
                        ),
                      ],
                    ),
                  ),
                )
                .toList(),
          ),
        );
      case 'blockquote':
        return Container(
          margin: const EdgeInsets.symmetric(vertical: 12),
          padding: const EdgeInsets.fromLTRB(16, 12, 12, 12),
          decoration: BoxDecoration(
            border: Border(
              left: BorderSide(color: theme.colorScheme.primary, width: 3),
            ),
          ),
          child: Text(
            block.text ?? '',
            style: theme.textTheme.bodyLarge?.copyWith(
              fontStyle: FontStyle.italic,
            ),
          ),
        );
      case 'paragraph':
      default:
        return Padding(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: Text(block.text ?? '', style: theme.textTheme.bodyLarge),
        );
    }
  }

  void _shareStory() {
    if (_story == null) return;
    final url = _story!.canonicalUrl ?? 'https://newsdarpan.in';
    Share.share('${_story!.title}\n$url');
  }
}

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../app/providers.dart';
import '../../core/l10n/app_strings.dart';

/// Contact Us screen with clearly visible contact information.
class ContactScreen extends ConsumerWidget {
  const ContactScreen({super.key});

  Future<void> _launchUrl(String url) async {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final appState = ref.watch(appStateProvider);
    final strings = AppStrings(appState.language);
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(title: Text(strings.contactUs)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Header
          Text(
            strings.contactUs,
            style: theme.textTheme.headlineSmall?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            strings.contactSubtitle,
            style: theme.textTheme.bodyMedium?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
          const SizedBox(height: 24),

          // Phone
          Card(
            child: ListTile(
              leading: Icon(Icons.phone, color: theme.colorScheme.primary),
              title: Text(strings.phone),
              subtitle: const Text('+91-98330 00048'),
              trailing: const Icon(Icons.open_in_new, size: 18),
              onTap: () => _launchUrl('tel:+919833000048'),
            ),
          ),
          const SizedBox(height: 8),

          // Primary Email
          Card(
            child: ListTile(
              leading: Icon(Icons.email, color: theme.colorScheme.primary),
              title: Text(strings.email),
              subtitle: const Text('admin@newsdarpan.in'),
              trailing: const Icon(Icons.open_in_new, size: 18),
              onTap: () => _launchUrl('mailto:admin@newsdarpan.in'),
            ),
          ),
          const SizedBox(height: 8),

          // Registered Office
          Card(
            child: ListTile(
              leading: Icon(
                Icons.location_on,
                color: theme.colorScheme.primary,
              ),
              title: Text(strings.registeredOffice),
              subtitle: const Text(
                'X/545, Jai Mata Gali, RaghubarPura No.1,\n'
                'Gandhi Nagar, East Delhi \u2013 110031',
              ),
              isThreeLine: true,
            ),
          ),
          const SizedBox(height: 24),

          // Desk Emails
          Text(
            strings.deskEmails,
            style: theme.textTheme.titleMedium?.copyWith(
              color: theme.colorScheme.primary,
            ),
          ),
          const SizedBox(height: 8),
          _DeskEmailTile(
            label: 'Admin',
            email: 'admin@newsdarpan.in',
            onTap: () => _launchUrl('mailto:admin@newsdarpan.in'),
          ),
          _DeskEmailTile(
            label: 'Editor',
            email: 'editor@newsdarpan.in',
            onTap: () => _launchUrl('mailto:editor@newsdarpan.in'),
          ),
          _DeskEmailTile(
            label: 'Corrections',
            email: 'corrections@newsdarpan.in',
            onTap: () => _launchUrl('mailto:corrections@newsdarpan.in'),
          ),
          _DeskEmailTile(
            label: 'Legal',
            email: 'legal@newsdarpan.in',
            onTap: () => _launchUrl('mailto:legal@newsdarpan.in'),
          ),
          const SizedBox(height: 24),

          // Website link
          Card(
            child: ListTile(
              leading: Icon(Icons.language, color: theme.colorScheme.primary),
              title: Text(strings.website),
              subtitle: const Text('https://newsdarpan.in/contact/'),
              trailing: const Icon(Icons.open_in_new, size: 18),
              onTap: () => _launchUrl('https://newsdarpan.in/contact/'),
            ),
          ),
        ],
      ),
    );
  }
}

class _DeskEmailTile extends StatelessWidget {
  final String label;
  final String email;
  final VoidCallback onTap;

  const _DeskEmailTile({
    required this.label,
    required this.email,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      dense: true,
      leading: const Icon(Icons.mail_outline, size: 20),
      title: Text(label),
      subtitle: Text(email),
      trailing: const Icon(Icons.open_in_new, size: 16),
      onTap: onTap,
    );
  }
}

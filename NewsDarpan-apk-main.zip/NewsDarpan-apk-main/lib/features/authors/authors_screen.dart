import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../app/providers.dart';
import '../../core/l10n/app_strings.dart';
import '../../core/network/api_exception.dart';
import '../../domain/models/story.dart';
import '../../shared/widgets/states.dart';

/// Authors screen: lists authors or shows single author profile + stories.
class AuthorsScreen extends ConsumerStatefulWidget {
  final String? authorSlug;

  const AuthorsScreen({super.key, this.authorSlug});

  @override
  ConsumerState<AuthorsScreen> createState() => _AuthorsScreenState();
}

class _AuthorsScreenState extends ConsumerState<AuthorsScreen> {
  List<Author>? _authors;
  Author? _selectedAuthor;
  bool _isLoading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });
    try {
      final repo = ref.read(newsRepositoryProvider);
      if (widget.authorSlug != null) {
        // Load author's stories
        final authors = await repo.getAuthors();
        final author = authors.where((a) => a.authorSlug == widget.authorSlug);
        if (author.isNotEmpty) {
          _selectedAuthor = author.first;
        }
      } else {
        _authors = await repo.getAuthors();
      }
      if (mounted) setState(() => _isLoading = false);
    } on ApiException catch (e) {
      if (mounted) {
        setState(() {
          _error = e.message;
          _isLoading = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _error = e.toString();
          _isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final appState = ref.watch(appStateProvider);
    final strings = AppStrings(appState.language);
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.authorSlug != null
              ? (_selectedAuthor?.fullName ?? strings.authors)
              : strings.authors,
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => context.pop(),
          tooltip: 'Back',
        ),
      ),
      body: _buildBody(theme, strings),
    );
  }

  Widget _buildBody(ThemeData theme, AppStrings strings) {
    if (_isLoading) return LoadingState(message: strings.loading);
    if (_error != null) return ErrorState(message: _error!, onRetry: _loadData);

    // Author profile
    if (widget.authorSlug != null && _selectedAuthor != null) {
      return _buildAuthorProfile(theme, _selectedAuthor!);
    }

    // Authors list
    if (_authors == null || _authors!.isEmpty) {
      return EmptyState(title: strings.noContent);
    }

    return ListView.builder(
      padding: const EdgeInsets.symmetric(vertical: 8),
      itemCount: _authors!.length,
      itemBuilder: (context, index) {
        final author = _authors![index];
        return ListTile(
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 16,
            vertical: 8,
          ),
          leading: CircleAvatar(
            radius: 24,
            backgroundImage:
                author.avatarUrl != null && author.avatarUrl!.isNotEmpty
                ? CachedNetworkImageProvider(author.avatarUrl!)
                : null,
            child: author.avatarUrl == null || author.avatarUrl!.isEmpty
                ? Text(author.fullName.isNotEmpty ? author.fullName[0] : '?')
                : null,
          ),
          title: Text(author.fullName),
          subtitle: author.title != null ? Text(author.title!) : null,
          onTap: () {
            if (author.authorSlug != null) {
              context.push('/author/${author.authorSlug}');
            }
          },
        );
      },
    );
  }

  Widget _buildAuthorProfile(ThemeData theme, Author author) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Column(
        children: [
          CircleAvatar(
            radius: 48,
            backgroundImage:
                author.avatarUrl != null && author.avatarUrl!.isNotEmpty
                ? CachedNetworkImageProvider(author.avatarUrl!)
                : null,
            child: author.avatarUrl == null || author.avatarUrl!.isEmpty
                ? Text(
                    author.fullName.isNotEmpty ? author.fullName[0] : '?',
                    style: theme.textTheme.headlineLarge,
                  )
                : null,
          ),
          const SizedBox(height: 16),
          Text(
            author.fullName,
            style: theme.textTheme.headlineMedium,
            textAlign: TextAlign.center,
          ),
          if (author.title != null) ...[
            const SizedBox(height: 4),
            Text(
              author.title!,
              style: theme.textTheme.titleMedium?.copyWith(
                color: theme.colorScheme.primary,
              ),
            ),
          ],
          if (author.bio != null) ...[
            const SizedBox(height: 16),
            Text(
              author.bio!,
              style: theme.textTheme.bodyLarge,
              textAlign: TextAlign.center,
            ),
          ],
        ],
      ),
    );
  }
}

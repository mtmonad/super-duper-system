import '../../core/config/app_config.dart';
import '../../domain/models/feed.dart';
import '../../domain/models/story.dart';

/// Maps raw API JSON responses to domain models.
class Mappers {
  Mappers._();

  /// Resolve a potentially relative image URL to absolute.
  static String resolveImageUrl(String? url) {
    if (url == null || url.isEmpty) return '';
    if (url.startsWith('http')) return url;
    return '${AppConfig.imageBaseUrl}$url';
  }

  static Story storyFromJson(Map<String, dynamic> json) {
    return Story(
      id: json['id']?.toString() ?? '',
      language: json['language']?.toString() ?? 'hi',
      title: json['title']?.toString() ?? '',
      slug: json['slug']?.toString() ?? '',
      dek: json['dek']?.toString(),
      canonicalUrl: json['canonical_url']?.toString(),
      section: json['section'] != null
          ? sectionFromJson(json['section'] as Map<String, dynamic>)
          : null,
      author: json['author'] != null
          ? authorFromJson(json['author'] as Map<String, dynamic>)
          : null,
      image: json['image'] != null
          ? imageFromJson(json['image'] as Map<String, dynamic>)
          : null,
      storyType: json['story_type']?.toString(),
      publishedAt: json['published_at'] != null
          ? DateTime.tryParse(json['published_at'].toString())
          : null,
      updatedAt: json['updated_at'] != null
          ? DateTime.tryParse(json['updated_at'].toString())
          : null,
      readingTimeMinutes: json['reading_time_minutes'] as int?,
      isLiveBlog: json['is_live_blog'] == true,
      liveBlogEnded: json['live_blog_ended'] == true,
      region: json['region']?.toString(),
      bodyBlocks: json['body_blocks'] != null
          ? (json['body_blocks'] as List)
                .map((b) => bodyBlockFromJson(b as Map<String, dynamic>))
                .toList()
          : null,
      bodyHtml: json['body_html']?.toString(),
    );
  }

  static Section sectionFromJson(Map<String, dynamic> json) {
    return Section(
      id: json['id']?.toString() ?? '',
      name: json['name']?.toString() ?? '',
      slug: json['slug']?.toString() ?? '',
    );
  }

  static Author authorFromJson(Map<String, dynamic> json) {
    return Author(
      id: json['id']?.toString(),
      fullName:
          json['full_name']?.toString() ??
          json['name']?.toString() ??
          'Unknown',
      authorSlug: json['author_slug']?.toString() ?? json['slug']?.toString(),
      title: json['title']?.toString(),
      bio: json['bio']?.toString(),
      avatarUrl: resolveImageUrl(json['avatar_url']?.toString()),
      profileUrl: json['profile_url']?.toString(),
    );
  }

  static StoryImage imageFromJson(Map<String, dynamic> json) {
    return StoryImage(
      id: json['id']?.toString(),
      kind: json['kind']?.toString(),
      url: resolveImageUrl(json['url']?.toString()),
      caption: json['caption']?.toString(),
      altText: json['alt_text']?.toString(),
      credit: json['credit']?.toString(),
      isAiGenerated: json['is_ai_generated'] == true,
    );
  }

  static BodyBlock bodyBlockFromJson(Map<String, dynamic> json) {
    return BodyBlock(
      type: json['type']?.toString() ?? 'paragraph',
      text: json['text']?.toString(),
      url: json['url'] != null ? resolveImageUrl(json['url'].toString()) : null,
      caption: json['caption']?.toString(),
      items: json['items'] != null
          ? (json['items'] as List).map((i) => i.toString()).toList()
          : null,
    );
  }

  static BootstrapData bootstrapFromJson(Map<String, dynamic> json) {
    final sections = (json['sections'] as List? ?? [])
        .map((s) => sectionFromJson(s as Map<String, dynamic>))
        .toList();
    final legalPages = (json['legal_pages'] as List? ?? [])
        .map(
          (p) => LegalPageRef(
            slug: p['slug']?.toString() ?? '',
            title: p['title']?.toString() ?? '',
          ),
        )
        .toList();
    return BootstrapData(
      brandName: json['brand']?['name']?.toString() ?? 'NewsDarpan',
      sections: sections,
      legalPages: legalPages,
    );
  }
}

import '../../core/network/api_client.dart';
import '../../domain/models/feed.dart';
import '../../domain/models/story.dart';
import '../../domain/repositories/news_repository.dart';
import '../dto/mappers.dart';

/// Production implementation of [NewsRepository] backed by the live API.
class ApiNewsRepository implements NewsRepository {
  final ApiClient client;

  ApiNewsRepository({required this.client});

  @override
  Future<BootstrapData> getBootstrap() async {
    final json = await client.get('bootstrap/bootstrap/');
    return Mappers.bootstrapFromJson(json);
  }

  @override
  Future<PaginatedList<Story>> getStories({
    String? language,
    String? cursor,
    String? sectionSlug,
  }) async {
    final params = <String, dynamic>{};
    if (language != null) params['lang'] = language;
    if (cursor != null) params['cursor'] = cursor;
    if (sectionSlug != null) params['section'] = sectionSlug;

    final json = await client.getPaginated('stories/', queryParams: params);
    final results = (json['results'] as List? ?? [])
        .map((s) => Mappers.storyFromJson(s as Map<String, dynamic>))
        .toList();
    final nextCursor = _extractCursor(json['next']?.toString());
    return PaginatedList(items: results, nextCursor: nextCursor);
  }

  @override
  Future<Story?> getStoryDetail(String id) async {
    final json = await client.get('stories/$id/');
    return Mappers.storyFromJson(json);
  }

  @override
  Future<PaginatedList<Story>> searchStories({
    required String query,
    String? language,
    String? cursor,
  }) async {
    final params = <String, dynamic>{'q': query};
    if (language != null) params['lang'] = language;
    if (cursor != null) params['cursor'] = cursor;

    final json = await client.getPaginated('search/', queryParams: params);
    final results = (json['results'] as List? ?? [])
        .map((s) => Mappers.storyFromJson(s as Map<String, dynamic>))
        .toList();
    final nextCursor = _extractCursor(json['next']?.toString());
    return PaginatedList(items: results, nextCursor: nextCursor);
  }

  @override
  Future<List<Author>> getAuthors() async {
    final list = await client.getList('authors/');
    return list
        .map((a) => Mappers.authorFromJson(a as Map<String, dynamic>))
        .toList();
  }

  @override
  Future<PaginatedList<Story>> getAuthorStories(
    String authorSlug, {
    String? cursor,
  }) async {
    final params = <String, dynamic>{};
    if (cursor != null) params['cursor'] = cursor;

    final json = await client.getPaginated(
      'authors/$authorSlug/stories/',
      queryParams: params,
    );
    final results = (json['results'] as List? ?? [])
        .map((s) => Mappers.storyFromJson(s as Map<String, dynamic>))
        .toList();
    final nextCursor = _extractCursor(json['next']?.toString());
    return PaginatedList(items: results, nextCursor: nextCursor);
  }

  /// Extracts cursor parameter from a next-page URL.
  String? _extractCursor(String? nextUrl) {
    if (nextUrl == null || nextUrl == 'null' || nextUrl.isEmpty) return null;
    final uri = Uri.tryParse(nextUrl);
    return uri?.queryParameters['cursor'];
  }
}

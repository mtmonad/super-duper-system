import '../../domain/models/feed.dart';
import '../../domain/models/story.dart';
import '../../domain/repositories/news_repository.dart';
import '../preview/preview_data.dart';

/// Preview/mock implementation of [NewsRepository].
///
/// Only active when --dart-define=USE_PREVIEW_DATA=true.
class PreviewNewsRepository implements NewsRepository {
  @override
  Future<BootstrapData> getBootstrap() async {
    await _simulateDelay();
    return PreviewData.bootstrap;
  }

  @override
  Future<PaginatedList<Story>> getStories({
    String? language,
    String? cursor,
    String? sectionSlug,
  }) async {
    await _simulateDelay();
    return PaginatedList(items: PreviewData.stories, nextCursor: null);
  }

  @override
  Future<Story?> getStoryDetail(String id) async {
    await _simulateDelay();
    try {
      return PreviewData.stories.firstWhere((s) => s.id == id);
    } catch (_) {
      return PreviewData.storyDetail;
    }
  }

  @override
  Future<PaginatedList<Story>> searchStories({
    required String query,
    String? language,
    String? cursor,
  }) async {
    await _simulateDelay();
    final filtered = PreviewData.stories
        .where((s) => s.title.toLowerCase().contains(query.toLowerCase()))
        .toList();
    return PaginatedList(items: filtered, nextCursor: null);
  }

  @override
  Future<List<Author>> getAuthors() async {
    await _simulateDelay();
    return PreviewData.authors;
  }

  @override
  Future<PaginatedList<Story>> getAuthorStories(
    String authorSlug, {
    String? cursor,
  }) async {
    await _simulateDelay();
    return PaginatedList(items: PreviewData.stories.take(3).toList());
  }

  Future<void> _simulateDelay() =>
      Future<void>.delayed(const Duration(milliseconds: 300));
}

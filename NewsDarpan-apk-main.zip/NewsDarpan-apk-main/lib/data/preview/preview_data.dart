import '../../domain/models/feed.dart';
import '../../domain/models/story.dart';

/// Mock data for preview mode (--dart-define=USE_PREVIEW_DATA=true).
///
/// This data is NEVER used in production builds. It exists solely for
/// UI development without a live backend.
class PreviewData {
  PreviewData._();

  static final BootstrapData bootstrap = BootstrapData(
    brandName: 'NewsDarpan',
    sections: [
      const Section(id: '1', name: 'राष्ट्रीय', slug: 'national'),
      const Section(id: '2', name: 'अंतरराष्ट्रीय', slug: 'international'),
      const Section(id: '3', name: 'खेल', slug: 'sports'),
      const Section(id: '4', name: 'मनोरंजन', slug: 'entertainment'),
      const Section(id: '5', name: 'विज्ञान', slug: 'science'),
      const Section(id: '6', name: 'व्यापार', slug: 'business'),
    ],
    legalPages: [
      const LegalPageRef(slug: 'privacy-policy', title: 'Privacy Policy'),
      const LegalPageRef(slug: 'terms-of-service', title: 'Terms of Service'),
      const LegalPageRef(slug: 'about', title: 'About'),
    ],
  );

  static final List<Section> sections = bootstrap.sections;

  static final List<Author> authors = [
    const Author(
      id: 'a1',
      fullName: 'राहुल शर्मा',
      authorSlug: 'rahul-sharma',
      title: 'वरिष्ठ संवाददाता',
      bio: 'राष्ट्रीय मामलों के विशेषज्ञ।',
      avatarUrl: '',
    ),
    const Author(
      id: 'a2',
      fullName: 'Priya Singh',
      authorSlug: 'priya-singh',
      title: 'Senior Correspondent',
      bio: 'Covers international affairs and diplomacy.',
      avatarUrl: '',
    ),
  ];

  static final List<Story> stories = [
    Story(
      id: 'preview-1',
      language: 'hi',
      title: 'भारत में डिजिटल शिक्षा का नया युग शुरू',
      slug: 'digital-education-new-era',
      dek:
          'सरकार ने ग्रामीण क्षेत्रों में डिजिटल शिक्षा के लिए नई योजना की घोषणा की।',
      canonicalUrl:
          'https://newsdarpan.in/hi/article/digital-education-new-era',
      section: const Section(id: '1', name: 'राष्ट्रीय', slug: 'national'),
      author: authors[0],
      image: const StoryImage(
        url: 'https://via.placeholder.com/800x450',
        altText: 'Digital education illustration',
        isAiGenerated: false,
      ),
      storyType: 'general',
      publishedAt: DateTime.now().subtract(const Duration(hours: 2)),
      updatedAt: DateTime.now().subtract(const Duration(hours: 1)),
      readingTimeMinutes: 5,
    ),
    Story(
      id: 'preview-2',
      language: 'hi',
      title: 'क्रिकेट विश्व कप: भारत ने सेमीफाइनल में प्रवेश किया',
      slug: 'cricket-world-cup-semifinal',
      dek: 'भारतीय टीम ने शानदार प्रदर्शन के साथ सेमीफाइनल में जगह पक्की की।',
      canonicalUrl:
          'https://newsdarpan.in/hi/article/cricket-world-cup-semifinal',
      section: const Section(id: '3', name: 'खेल', slug: 'sports'),
      author: authors[0],
      image: const StoryImage(
        url: 'https://via.placeholder.com/800x450',
        altText: 'Cricket match',
        isAiGenerated: false,
      ),
      storyType: 'general',
      publishedAt: DateTime.now().subtract(const Duration(hours: 4)),
      readingTimeMinutes: 3,
    ),
    Story(
      id: 'preview-3',
      language: 'en',
      title: 'Global Climate Summit: Key Agreements Reached',
      slug: 'global-climate-summit-agreements',
      dek:
          'World leaders commit to ambitious targets at the climate conference.',
      canonicalUrl:
          'https://newsdarpan.in/en/article/global-climate-summit-agreements',
      section: const Section(
        id: '2',
        name: 'International',
        slug: 'international',
      ),
      author: authors[1],
      image: const StoryImage(
        url: 'https://via.placeholder.com/800x450',
        altText: 'Climate summit',
        isAiGenerated: true,
      ),
      storyType: 'general',
      publishedAt: DateTime.now().subtract(const Duration(hours: 6)),
      readingTimeMinutes: 7,
    ),
  ];

  static final Story storyDetail = Story(
    id: 'preview-1',
    language: 'hi',
    title: 'भारत में डिजिटल शिक्षा का नया युग शुरू',
    slug: 'digital-education-new-era',
    dek:
        'सरकार ने ग्रामीण क्षेत्रों में डिजिटल शिक्षा के लिए नई योजना की घोषणा की।',
    canonicalUrl: 'https://newsdarpan.in/hi/article/digital-education-new-era',
    section: const Section(id: '1', name: 'राष्ट्रीय', slug: 'national'),
    author: authors[0],
    image: const StoryImage(
      url: 'https://via.placeholder.com/800x450',
      altText: 'Digital education illustration',
      isAiGenerated: false,
    ),
    storyType: 'general',
    publishedAt: DateTime.now().subtract(const Duration(hours: 2)),
    updatedAt: DateTime.now().subtract(const Duration(hours: 1)),
    readingTimeMinutes: 5,
    bodyBlocks: [
      const BodyBlock(
        type: 'paragraph',
        text:
            'सरकार ने आज एक महत्वपूर्ण कदम उठाते हुए ग्रामीण भारत में डिजिटल शिक्षा के विस्तार के लिए एक व्यापक योजना की घोषणा की।',
      ),
      const BodyBlock(type: 'heading', text: 'मुख्य बिंदु'),
      const BodyBlock(
        type: 'list',
        items: [
          'सभी ग्रामीण स्कूलों में इंटरनेट कनेक्टिविटी',
          'शिक्षकों के लिए डिजिटल प्रशिक्षण',
          'छात्रों को टैबलेट वितरण',
        ],
      ),
      const BodyBlock(
        type: 'paragraph',
        text: 'यह योजना अगले तीन वर्षों में चरणबद्ध तरीके से लागू की जाएगी।',
      ),
    ],
  );
}

/// Represents a section/category of news.
class Section {
  final String id;
  final String name;
  final String slug;

  const Section({required this.id, required this.name, required this.slug});
}

/// Bootstrap response containing brand, sections, and legal pages.
class BootstrapData {
  final String brandName;
  final List<Section> sections;
  final List<LegalPageRef> legalPages;

  const BootstrapData({
    required this.brandName,
    required this.sections,
    required this.legalPages,
  });
}

/// Reference to a legal page.
class LegalPageRef {
  final String slug;
  final String title;

  const LegalPageRef({required this.slug, required this.title});
}

/// A paginated list response.
class PaginatedList<T> {
  final List<T> items;
  final String? nextCursor;

  const PaginatedList({required this.items, this.nextCursor});

  bool get hasMore => nextCursor != null;
}

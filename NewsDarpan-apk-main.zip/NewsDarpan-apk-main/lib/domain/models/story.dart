import 'feed.dart';

/// Image metadata for a story.
class StoryImage {
  final String? id;
  final String? kind;
  final String url;
  final String? caption;
  final String? altText;
  final String? credit;
  final bool isAiGenerated;

  const StoryImage({
    this.id,
    this.kind,
    required this.url,
    this.caption,
    this.altText,
    this.credit,
    this.isAiGenerated = false,
  });
}

/// Author information.
class Author {
  final String? id;
  final String fullName;
  final String? authorSlug;
  final String? title;
  final String? bio;
  final String? avatarUrl;
  final String? profileUrl;

  const Author({
    this.id,
    required this.fullName,
    this.authorSlug,
    this.title,
    this.bio,
    this.avatarUrl,
    this.profileUrl,
  });
}

/// A news story (summary + detail).
class Story {
  final String id;
  final String language;
  final String title;
  final String slug;
  final String? dek;
  final String? canonicalUrl;
  final Section? section;
  final Author? author;
  final StoryImage? image;
  final String? storyType;
  final DateTime? publishedAt;
  final DateTime? updatedAt;
  final int? readingTimeMinutes;
  final bool isLiveBlog;
  final bool liveBlogEnded;
  final String? region;

  // Detail fields
  final List<BodyBlock>? bodyBlocks;
  final String? bodyHtml;

  const Story({
    required this.id,
    required this.language,
    required this.title,
    required this.slug,
    this.dek,
    this.canonicalUrl,
    this.section,
    this.author,
    this.image,
    this.storyType,
    this.publishedAt,
    this.updatedAt,
    this.readingTimeMinutes,
    this.isLiveBlog = false,
    this.liveBlogEnded = false,
    this.region,
    this.bodyBlocks,
    this.bodyHtml,
  });
}

/// A structured body block from the story detail.
class BodyBlock {
  final String type; // paragraph, heading, image, list, blockquote, etc.
  final String? text;
  final String? url;
  final String? caption;
  final List<String>? items;

  const BodyBlock({
    required this.type,
    this.text,
    this.url,
    this.caption,
    this.items,
  });
}

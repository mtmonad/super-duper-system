import '../models/feed.dart';
import '../models/story.dart';

/// Abstract contract for the news data layer.
///
/// Implemented by [ApiNewsRepository] for production and
/// [PreviewNewsRepository] for preview/mock data.
abstract class NewsRepository {
  /// Fetch bootstrap data (sections, brand, legal pages).
  Future<BootstrapData> getBootstrap();

  /// Fetch a paginated list of stories.
  Future<PaginatedList<Story>> getStories({
    String? language,
    String? cursor,
    String? sectionSlug,
  });

  /// Fetch a single story detail by ID.
  Future<Story?> getStoryDetail(String id);

  /// Search stories.
  Future<PaginatedList<Story>> searchStories({
    required String query,
    String? language,
    String? cursor,
  });

  /// Fetch authors list.
  Future<List<Author>> getAuthors();

  /// Fetch stories by author slug.
  Future<PaginatedList<Story>> getAuthorStories(
    String authorSlug, {
    String? cursor,
  });
}

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../core/network/api_client.dart';
import '../core/storage/preferences_store.dart';
import '../data/repositories/api_news_repository.dart';
import '../data/repositories/preview_news_repository.dart';
import '../domain/models/story.dart';
import '../domain/repositories/news_repository.dart';
import 'app_state.dart';

// ---------- Configuration ----------

/// Whether to use preview/mock data (--dart-define=USE_PREVIEW_DATA=true).
const bool usePreviewData = bool.fromEnvironment(
  'USE_PREVIEW_DATA',
  defaultValue: false,
);

// ---------- Core dependencies ----------

final sharedPreferencesProvider = FutureProvider<SharedPreferences>((
  ref,
) async {
  return SharedPreferences.getInstance();
});

final preferencesStoreProvider = Provider<PreferencesStore>((ref) {
  final asyncPrefs = ref.watch(sharedPreferencesProvider);
  return asyncPrefs.when(
    data: (prefs) => PreferencesStore(prefs),
    loading: () => PreferencesStore.empty(),
    error: (_, _) => PreferencesStore.empty(),
  );
});

final apiClientProvider = Provider<ApiClient>((ref) {
  final store = ref.watch(preferencesStoreProvider);
  return ApiClient(languageProvider: () => store.language);
});

// ---------- Repository ----------

final newsRepositoryProvider = Provider<NewsRepository>((ref) {
  if (usePreviewData) {
    return PreviewNewsRepository();
  }
  final client = ref.watch(apiClientProvider);
  return ApiNewsRepository(client: client);
});

// ---------- App state ----------

final appStateProvider = StateNotifierProvider<AppStateNotifier, AppState>((
  ref,
) {
  final store = ref.watch(preferencesStoreProvider);
  return AppStateNotifier(store);
});

class AppStateNotifier extends StateNotifier<AppState> {
  final PreferencesStore _store;

  AppStateNotifier(this._store)
    : super(
        AppState(
          onboardingComplete: _store.onboardingComplete,
          language: _store.language,
          isDarkMode: _store.isDarkMode,
          textScale: _store.textScale,
        ),
      );

  void completeOnboarding() {
    _store.setOnboardingComplete(true);
    state = state.copyWith(onboardingComplete: true);
  }

  void setLanguage(String lang) {
    _store.setLanguage(lang);
    state = state.copyWith(language: lang);
  }

  void toggleTheme() {
    final dark = !state.isDarkMode;
    _store.setDarkMode(dark);
    state = state.copyWith(isDarkMode: dark);
  }

  void setTextScale(double scale) {
    _store.setTextScale(scale);
    state = state.copyWith(textScale: scale);
  }
}

// ---------- Theme / locale derived providers ----------

final themeModeProvider = Provider<ThemeMode>((ref) {
  final appState = ref.watch(appStateProvider);
  return appState.isDarkMode ? ThemeMode.dark : ThemeMode.light;
});

final localeProvider = Provider<Locale>((ref) {
  final appState = ref.watch(appStateProvider);
  return Locale(appState.language, 'IN');
});

// ---------- Bookmarks ----------

final bookmarksProvider = StateNotifierProvider<BookmarksNotifier, Set<String>>(
  (ref) {
    final store = ref.watch(preferencesStoreProvider);
    return BookmarksNotifier(store);
  },
);

class BookmarksNotifier extends StateNotifier<Set<String>> {
  final PreferencesStore _store;

  BookmarksNotifier(this._store) : super(_store.bookmarkedIds.toSet());

  void toggle(String storyId) {
    if (state.contains(storyId)) {
      state = {...state}..remove(storyId);
    } else {
      state = {...state, storyId};
    }
    _store.setBookmarks(state.toList());
  }

  bool isBookmarked(String storyId) => state.contains(storyId);
}

// ---------- Saved stories ----------

final savedStoriesProvider = FutureProvider<List<Story>>((ref) async {
  final bookmarks = ref.watch(bookmarksProvider);
  if (bookmarks.isEmpty) return [];
  final repo = ref.read(newsRepositoryProvider);
  final stories = <Story>[];
  for (final id in bookmarks) {
    try {
      final story = await repo.getStoryDetail(id);
      if (story != null) stories.add(story);
    } catch (_) {
      // Skip stories that can't be loaded
    }
  }
  return stories;
});

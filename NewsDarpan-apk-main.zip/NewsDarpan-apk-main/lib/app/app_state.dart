/// Application-level state definitions for NewsDarpan Reader.
///
/// Tracks onboarding completion, selected language, and theme preference.
class AppState {
  final bool onboardingComplete;
  final String language; // 'hi' or 'en'
  final bool isDarkMode;
  final double textScale;

  const AppState({
    this.onboardingComplete = false,
    this.language = 'hi',
    this.isDarkMode = false,
    this.textScale = 1.0,
  });

  AppState copyWith({
    bool? onboardingComplete,
    String? language,
    bool? isDarkMode,
    double? textScale,
  }) {
    return AppState(
      onboardingComplete: onboardingComplete ?? this.onboardingComplete,
      language: language ?? this.language,
      isDarkMode: isDarkMode ?? this.isDarkMode,
      textScale: textScale ?? this.textScale,
    );
  }
}

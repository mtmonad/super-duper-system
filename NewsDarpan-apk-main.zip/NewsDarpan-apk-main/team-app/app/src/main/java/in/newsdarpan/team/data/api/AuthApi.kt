package `in`.newsdarpan.team.data.api

import `in`.newsdarpan.team.data.model.*
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST

/**
 * Authentication API for staff users.
 * Endpoint: POST https://newsdarpan.in/api/v1/auth/token/
 */
interface AuthApi {

    @POST("api/v1/auth/token/")
    suspend fun login(@Body request: LoginRequest): Response<TokenResponse>

    @POST("api/v1/auth/token/refresh/")
    suspend fun refreshToken(@Body request: RefreshTokenRequest): Response<TokenResponse>

    @GET("api/staff/v1/me/")
    suspend fun getCurrentUser(): Response<UserDto>
}

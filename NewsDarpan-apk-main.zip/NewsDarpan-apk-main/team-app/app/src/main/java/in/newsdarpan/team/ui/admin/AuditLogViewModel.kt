package `in`.newsdarpan.team.ui.admin

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import `in`.newsdarpan.team.data.api.StaffApi
import `in`.newsdarpan.team.data.model.toDomain
import `in`.newsdarpan.team.domain.model.AuditEntry
import `in`.newsdarpan.team.util.Result
import `in`.newsdarpan.team.util.safeApiCall
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class AuditLogUiState(
    val entries: List<AuditEntry> = emptyList(),
    val isLoading: Boolean = true,
    val error: String? = null
)

@HiltViewModel
class AuditLogViewModel @Inject constructor(
    private val staffApi: StaffApi
) : ViewModel() {

    private val _uiState = MutableStateFlow(AuditLogUiState())
    val uiState: StateFlow<AuditLogUiState> = _uiState.asStateFlow()

    init {
        loadAuditLog()
    }

    fun loadAuditLog() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            when (val result = safeApiCall { staffApi.getAuditLog() }) {
                is Result.Success -> {
                    val entries = result.data.results.map { it.toDomain() }
                    _uiState.update { it.copy(entries = entries, isLoading = false) }
                }
                is Result.Error -> {
                    _uiState.update { it.copy(isLoading = false, error = result.message) }
                }
            }
        }
    }
}

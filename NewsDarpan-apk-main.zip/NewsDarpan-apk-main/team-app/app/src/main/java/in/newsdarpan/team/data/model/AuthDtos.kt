package `in`.newsdarpan.team.data.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class LoginRequest(
    val email: String,
    val password: String
)

@Serializable
data class RefreshTokenRequest(
    @SerialName("refresh") val refreshToken: String
)

@Serializable
data class TokenResponse(
    @SerialName("access") val accessToken: String,
    @SerialName("refresh") val refreshToken: String
)

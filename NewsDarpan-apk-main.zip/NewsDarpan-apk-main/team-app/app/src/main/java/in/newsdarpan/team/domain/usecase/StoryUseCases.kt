package `in`.newsdarpan.team.domain.usecase

import `in`.newsdarpan.team.data.repository.StoryRepository
import `in`.newsdarpan.team.domain.model.*
import `in`.newsdarpan.team.util.Result
import javax.inject.Inject

/**
 * Use case for fetching stories based on filters and user role.
 */
class GetStoriesUseCase @Inject constructor(
    private val storyRepository: StoryRepository
) {
    suspend operator fun invoke(
        status: StoryStatus? = null,
        authorId: Long? = null,
        sectionId: Long? = null,
        cursor: String? = null
    ): Result<PaginatedStories> {
        return storyRepository.getStories(status, authorId, sectionId, cursor)
    }
}

data class PaginatedStories(
    val stories: List<Story>,
    val nextCursor: String?,
    val totalCount: Int
)

/**
 * Use case for fetching a single story by ID.
 */
class GetStoryDetailUseCase @Inject constructor(
    private val storyRepository: StoryRepository
) {
    suspend operator fun invoke(storyId: Long): Result<Story> {
        return storyRepository.getStoryDetail(storyId)
    }
}

/**
 * Use case for creating a new story.
 * Available to users with CREATE_STORY capability.
 */
class CreateStoryUseCase @Inject constructor(
    private val storyRepository: StoryRepository
) {
    suspend operator fun invoke(
        title: String,
        summary: String,
        body: String,
        language: Language,
        sectionId: Long?,
        tags: List<Long> = emptyList(),
        regions: List<Long> = emptyList(),
        saveAsDraft: Boolean = true
    ): Result<Story> {
        if (title.isBlank()) {
            return Result.Error("Title is required")
        }
        return storyRepository.createStory(
            title = title,
            summary = summary,
            body = body,
            language = language,
            sectionId = sectionId,
            tags = tags,
            regions = regions,
            saveAsDraft = saveAsDraft
        )
    }
}

/**
 * Use case for updating an existing story.
 */
class UpdateStoryUseCase @Inject constructor(
    private val storyRepository: StoryRepository
) {
    suspend operator fun invoke(
        storyId: Long,
        title: String? = null,
        summary: String? = null,
        body: String? = null,
        sectionId: Long? = null,
        tags: List<Long>? = null,
        regions: List<Long>? = null
    ): Result<Story> {
        return storyRepository.updateStory(storyId, title, summary, body, sectionId, tags, regions)
    }
}

/**
 * Use case for performing a workflow transition on a story.
 * Backend enforces capability checks and no self-approval.
 */
class TransitionStoryUseCase @Inject constructor(
    private val storyRepository: StoryRepository
) {
    suspend operator fun invoke(
        storyId: Long,
        action: TransitionAction,
        comment: String? = null
    ): Result<Story> {
        return storyRepository.transitionStory(storyId, action, comment)
    }
}

/**
 * Use case for searching stories across all workflow states.
 */
class SearchStoriesUseCase @Inject constructor(
    private val storyRepository: StoryRepository
) {
    suspend operator fun invoke(query: String, cursor: String? = null): Result<PaginatedStories> {
        if (query.isBlank()) {
            return Result.Error("Search query cannot be empty")
        }
        return storyRepository.searchStories(query, cursor)
    }
}

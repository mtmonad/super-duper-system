package `in`.newsdarpan.team.data.model

import `in`.newsdarpan.team.domain.model.*

/**
 * Maps DTO objects from API to domain models.
 */
fun StoryDto.toDomain(): Story = Story(
    id = id,
    title = title,
    slug = slug,
    summary = summary,
    body = body,
    status = StoryStatus.fromString(status),
    language = Language.fromCode(language),
    section = section?.toDomain(),
    author = author.toDomain(),
    tags = tags.map { it.toDomain() },
    regions = regions.map { it.toDomain() },
    media = media.map { it.toDomain() },
    translationGroupId = translationGroupId,
    seo = seo?.toDomain(),
    qualityScore = qualityScore,
    riskTier = riskTier?.let { RiskTier.fromString(it) },
    legalHold = legalHold,
    editorNotes = editorNotes,
    createdAt = createdAt,
    updatedAt = updatedAt,
    publishedAt = publishedAt
)

fun StoryAuthorDto.toDomain(): StoryAuthor = StoryAuthor(
    id = id,
    name = name,
    avatarUrl = avatarUrl
)

fun SectionDto.toDomain(): Section = Section(
    id = id,
    name = name,
    slug = slug
)

fun TagDto.toDomain(): Tag = Tag(
    id = id,
    name = name,
    slug = slug
)

fun RegionDto.toDomain(): Region = Region(
    id = id,
    name = name,
    slug = slug
)

fun MediaAssetDto.toDomain(): MediaAsset = MediaAsset(
    id = id,
    url = url,
    type = MediaType.fromString(type),
    caption = caption,
    altText = altText,
    credit = credit,
    isAiGenerated = isAiGenerated,
    thumbnailUrl = thumbnailUrl,
    width = width,
    height = height,
    fileSize = fileSize,
    uploadedAt = uploadedAt
)

fun SeoRecordDto.toDomain(): SeoRecord = SeoRecord(
    title = title,
    description = description,
    keywords = keywords,
    faqItems = faqItems.map { FaqItem(it.question, it.answer) }
)

fun UserDto.toDomain(): User = User(
    id = id,
    email = email,
    fullName = fullName,
    role = UserRole.fromString(role),
    capabilities = capabilities.mapNotNull { Capability.fromString(it) },
    avatarUrl = avatarUrl,
    isActive = isActive
)

fun AuditEntryDto.toDomain(): AuditEntry = AuditEntry(
    id = id,
    storyId = storyId,
    storyTitle = storyTitle,
    action = action,
    actorName = actorName,
    actorRole = actorRole,
    comment = comment,
    timestamp = timestamp
)

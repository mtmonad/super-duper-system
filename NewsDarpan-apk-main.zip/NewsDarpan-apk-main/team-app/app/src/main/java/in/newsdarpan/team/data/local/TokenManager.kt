package `in`.newsdarpan.team.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "team_prefs")

/**
 * Manages JWT tokens securely using DataStore.
 */
@Singleton
class TokenManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    companion object {
        private val ACCESS_TOKEN_KEY = stringPreferencesKey("access_token")
        private val REFRESH_TOKEN_KEY = stringPreferencesKey("refresh_token")
        private val USER_ID_KEY = stringPreferencesKey("user_id")
        private val USER_EMAIL_KEY = stringPreferencesKey("user_email")
        private val USER_NAME_KEY = stringPreferencesKey("user_name")
        private val USER_ROLE_KEY = stringPreferencesKey("user_role")
        private val USER_CAPABILITIES_KEY = stringPreferencesKey("user_capabilities")
    }

    val accessToken: Flow<String?> = context.dataStore.data.map { prefs ->
        prefs[ACCESS_TOKEN_KEY]
    }

    val isLoggedIn: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[ACCESS_TOKEN_KEY] != null
    }

    suspend fun getAccessToken(): String? {
        return context.dataStore.data.first()[ACCESS_TOKEN_KEY]
    }

    suspend fun getRefreshToken(): String? {
        return context.dataStore.data.first()[REFRESH_TOKEN_KEY]
    }

    suspend fun saveTokens(accessToken: String, refreshToken: String) {
        context.dataStore.edit { prefs ->
            prefs[ACCESS_TOKEN_KEY] = accessToken
            prefs[REFRESH_TOKEN_KEY] = refreshToken
        }
    }

    suspend fun saveUserInfo(
        id: Long,
        email: String,
        name: String,
        role: String,
        capabilities: List<String>
    ) {
        context.dataStore.edit { prefs ->
            prefs[USER_ID_KEY] = id.toString()
            prefs[USER_EMAIL_KEY] = email
            prefs[USER_NAME_KEY] = name
            prefs[USER_ROLE_KEY] = role
            prefs[USER_CAPABILITIES_KEY] = capabilities.joinToString(",")
        }
    }

    suspend fun getUserId(): Long? {
        return context.dataStore.data.first()[USER_ID_KEY]?.toLongOrNull()
    }

    suspend fun getUserRole(): String? {
        return context.dataStore.data.first()[USER_ROLE_KEY]
    }

    suspend fun getUserCapabilities(): List<String> {
        val raw = context.dataStore.data.first()[USER_CAPABILITIES_KEY] ?: return emptyList()
        return raw.split(",").filter { it.isNotBlank() }
    }

    suspend fun clearAll() {
        context.dataStore.edit { it.clear() }
    }
}

package `in`.newsdarpan.team.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

// NewsDarpan Brand Colors
val NdPrimary = Color(0xFF1A237E)
val NdPrimaryVariant = Color(0xFF0D1652)
val NdSecondary = Color(0xFFFF6F00)
val NdSecondaryVariant = Color(0xFFC43E00)
val NdBackground = Color(0xFFFAFAFA)
val NdSurface = Color(0xFFFFFFFF)
val NdError = Color(0xFFB00020)
val NdOnPrimary = Color(0xFFFFFFFF)
val NdOnSecondary = Color(0xFFFFFFFF)
val NdOnBackground = Color(0xFF1C1B1F)
val NdOnSurface = Color(0xFF1C1B1F)

// Dark theme colors
val NdPrimaryDark = Color(0xFF5C6BC0)
val NdBackgroundDark = Color(0xFF121212)
val NdSurfaceDark = Color(0xFF1E1E1E)

// Status colors
val StatusDraft = Color(0xFF9E9E9E)
val StatusSubmitted = Color(0xFF2196F3)
val StatusInReview = Color(0xFFFF9800)
val StatusApproved = Color(0xFF4CAF50)
val StatusRejected = Color(0xFFF44336)
val StatusPublished = Color(0xFF1B5E20)

private val LightColorScheme = lightColorScheme(
    primary = NdPrimary,
    onPrimary = NdOnPrimary,
    primaryContainer = NdPrimary.copy(alpha = 0.12f),
    onPrimaryContainer = NdPrimary,
    secondary = NdSecondary,
    onSecondary = NdOnSecondary,
    secondaryContainer = NdSecondary.copy(alpha = 0.12f),
    onSecondaryContainer = NdSecondary,
    background = NdBackground,
    onBackground = NdOnBackground,
    surface = NdSurface,
    onSurface = NdOnSurface,
    error = NdError,
    onError = Color.White,
    surfaceVariant = Color(0xFFE8EAF6),
    onSurfaceVariant = Color(0xFF49454F)
)

private val DarkColorScheme = darkColorScheme(
    primary = NdPrimaryDark,
    onPrimary = NdOnPrimary,
    primaryContainer = NdPrimaryDark.copy(alpha = 0.12f),
    onPrimaryContainer = NdPrimaryDark,
    secondary = NdSecondary,
    onSecondary = NdOnSecondary,
    secondaryContainer = NdSecondary.copy(alpha = 0.12f),
    onSecondaryContainer = NdSecondary,
    background = NdBackgroundDark,
    onBackground = Color.White,
    surface = NdSurfaceDark,
    onSurface = Color.White,
    error = Color(0xFFCF6679),
    onError = Color.Black,
    surfaceVariant = Color(0xFF2C2C2C),
    onSurfaceVariant = Color(0xFFCAC4D0)
)

@Composable
fun NewsDarpanTeamTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography(),
        content = content
    )
}

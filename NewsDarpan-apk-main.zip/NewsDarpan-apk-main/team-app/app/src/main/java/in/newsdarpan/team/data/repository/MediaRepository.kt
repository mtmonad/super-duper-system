package `in`.newsdarpan.team.data.repository

import `in`.newsdarpan.team.data.api.StaffApi
import `in`.newsdarpan.team.data.model.toDomain
import `in`.newsdarpan.team.domain.model.MediaAsset
import `in`.newsdarpan.team.util.Result
import `in`.newsdarpan.team.util.map
import `in`.newsdarpan.team.util.safeApiCall
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MediaRepository @Inject constructor(
    private val staffApi: StaffApi
) {

    suspend fun uploadMedia(
        storyId: Long,
        file: File,
        caption: String?,
        altText: String?,
        credit: String?,
        isAiGenerated: Boolean
    ): Result<MediaAsset> {
        val mediaType = when {
            file.name.endsWith(".jpg", true) || file.name.endsWith(".jpeg", true) -> "image/jpeg"
            file.name.endsWith(".png", true) -> "image/png"
            file.name.endsWith(".webp", true) -> "image/webp"
            file.name.endsWith(".mp4", true) -> "video/mp4"
            file.name.endsWith(".mov", true) -> "video/quicktime"
            else -> "application/octet-stream"
        }

        val requestFile = file.asRequestBody(mediaType.toMediaTypeOrNull())
        val filePart = MultipartBody.Part.createFormData("file", file.name, requestFile)

        val textType = "text/plain".toMediaTypeOrNull()
        val captionBody = caption?.toRequestBody(textType)
        val altTextBody = altText?.toRequestBody(textType)
        val creditBody = credit?.toRequestBody(textType)
        val aiBody = isAiGenerated.toString().toRequestBody(textType)

        val result = safeApiCall {
            staffApi.uploadMedia(storyId, filePart, captionBody, altTextBody, creditBody, aiBody)
        }
        return result.map { it.toDomain() }
    }

    suspend fun deleteMedia(storyId: Long, mediaId: Long): Result<Unit> {
        return safeApiCall { staffApi.deleteMedia(storyId, mediaId) }
    }

    /**
     * Generate video from story content.
     * Only available to Editor and Administrator roles.
     * Backend enforces GENERATE_VIDEO capability check.
     */
    suspend fun generateVideo(storyId: Long): Result<MediaAsset> {
        val result = safeApiCall { staffApi.generateVideo(storyId) }
        return result.map { it.toDomain() }
    }
}

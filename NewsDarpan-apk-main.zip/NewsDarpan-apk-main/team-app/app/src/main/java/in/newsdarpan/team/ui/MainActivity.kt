package `in`.newsdarpan.team.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.navigation.compose.rememberNavController
import dagger.hilt.android.AndroidEntryPoint
import `in`.newsdarpan.team.data.local.TokenManager
import `in`.newsdarpan.team.ui.navigation.Routes
import `in`.newsdarpan.team.ui.navigation.TeamNavGraph
import `in`.newsdarpan.team.ui.theme.NewsDarpanTeamTheme
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import javax.inject.Inject

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    @Inject
    lateinit var tokenManager: TokenManager

    override fun onCreate(savedInstanceState: Bundle?) {
        val splashScreen = installSplashScreen()
        super.onCreate(savedInstanceState)

        // Determine start destination based on auth state
        val isLoggedIn = runBlocking { tokenManager.isLoggedIn.first() }
        val startDestination = if (isLoggedIn) Routes.DASHBOARD else Routes.LOGIN

        enableEdgeToEdge()

        setContent {
            NewsDarpanTeamTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val navController = rememberNavController()
                    TeamNavGraph(
                        navController = navController,
                        startDestination = startDestination
                    )
                }
            }
        }
    }
}

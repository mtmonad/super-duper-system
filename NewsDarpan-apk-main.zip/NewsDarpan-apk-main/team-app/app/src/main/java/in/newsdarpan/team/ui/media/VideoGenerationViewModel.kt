package `in`.newsdarpan.team.ui.media

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import `in`.newsdarpan.team.data.repository.AuthRepository
import `in`.newsdarpan.team.domain.model.Capability
import `in`.newsdarpan.team.domain.usecase.GenerateVideoUseCase
import `in`.newsdarpan.team.util.Result
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class VideoGenerationUiState(
    val storyId: Long? = null,
    val hasPermission: Boolean = false,
    val isGenerating: Boolean = false,
    val videoUrl: String? = null,
    val error: String? = null
)

/**
 * ViewModel for video generation.
 * Video generation is only available to users with Editor or Administrator roles
 * who have the GENERATE_VIDEO capability.
 */
@HiltViewModel
class VideoGenerationViewModel @Inject constructor(
    private val generateVideoUseCase: GenerateVideoUseCase,
    private val authRepository: AuthRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(VideoGenerationUiState())
    val uiState: StateFlow<VideoGenerationUiState> = _uiState.asStateFlow()

    fun setStoryId(storyId: Long) {
        _uiState.update { it.copy(storyId = storyId) }
        checkPermission()
    }

    private fun checkPermission() {
        viewModelScope.launch {
            val user = authRepository.getCurrentUser()
            val hasPermission = user?.capabilities?.contains(Capability.GENERATE_VIDEO) == true
            _uiState.update { it.copy(hasPermission = hasPermission) }
        }
    }

    fun generateVideo() {
        val storyId = _uiState.value.storyId ?: return

        viewModelScope.launch {
            _uiState.update { it.copy(isGenerating = true, error = null) }

            when (val result = generateVideoUseCase(storyId)) {
                is Result.Success -> {
                    _uiState.update {
                        it.copy(isGenerating = false, videoUrl = result.data.url)
                    }
                }
                is Result.Error -> {
                    _uiState.update {
                        it.copy(isGenerating = false, error = result.message)
                    }
                }
            }
        }
    }
}

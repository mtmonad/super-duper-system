package `in`.newsdarpan.team.domain.model

/**
 * Story represents a news article in any workflow state.
 * Staff app can access stories in all states unlike the reader app.
 */
data class Story(
    val id: Long,
    val title: String,
    val slug: String,
    val summary: String,
    val body: String,
    val status: StoryStatus,
    val language: Language,
    val section: Section?,
    val author: StoryAuthor,
    val tags: List<Tag> = emptyList(),
    val regions: List<Region> = emptyList(),
    val media: List<MediaAsset> = emptyList(),
    val translationGroupId: Long? = null,
    val seo: SeoRecord? = null,
    val qualityScore: Int? = null,
    val riskTier: RiskTier? = null,
    val legalHold: Boolean = false,
    val editorNotes: String? = null,
    val createdAt: String,
    val updatedAt: String,
    val publishedAt: String? = null
)

data class StoryAuthor(
    val id: Long,
    val name: String,
    val avatarUrl: String? = null
)

enum class StoryStatus(val displayName: String) {
    DRAFT("Draft"),
    SUBMITTED("Submitted"),
    IN_REVIEW("In Review"),
    APPROVED("Approved"),
    REJECTED("Rejected"),
    PUBLISHED("Published"),
    DEMOTED("Demoted"),
    ARCHIVED("Archived");

    companion object {
        fun fromString(value: String): StoryStatus {
            return entries.find { it.name.equals(value, ignoreCase = true) } ?: DRAFT
        }
    }
}

enum class Language(val code: String, val displayName: String) {
    ENGLISH("en", "English"),
    HINDI("hi", "Hindi");

    companion object {
        fun fromCode(code: String): Language {
            return entries.find { it.code.equals(code, ignoreCase = true) } ?: ENGLISH
        }
    }
}

data class Section(
    val id: Long,
    val name: String,
    val slug: String
)

data class Tag(
    val id: Long,
    val name: String,
    val slug: String
)

data class Region(
    val id: Long,
    val name: String,
    val slug: String
)

enum class RiskTier {
    LOW, MEDIUM, HIGH, CRITICAL;

    companion object {
        fun fromString(value: String): RiskTier? {
            return entries.find { it.name.equals(value, ignoreCase = true) }
        }
    }
}

data class SeoRecord(
    val title: String,
    val description: String,
    val keywords: List<String> = emptyList(),
    val faqItems: List<FaqItem> = emptyList()
)

data class FaqItem(
    val question: String,
    val answer: String
)

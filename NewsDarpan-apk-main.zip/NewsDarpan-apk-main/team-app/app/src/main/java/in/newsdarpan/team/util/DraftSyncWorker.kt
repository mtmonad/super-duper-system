package `in`.newsdarpan.team.util

import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.work.*
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import `in`.newsdarpan.team.data.local.DraftDao
import `in`.newsdarpan.team.data.repository.StoryRepository
import `in`.newsdarpan.team.domain.model.Language
import timber.log.Timber
import java.util.concurrent.TimeUnit

/**
 * WorkManager worker that syncs offline drafts when connectivity is restored.
 * Ensures no content is lost when reporters are in the field without network.
 */
@HiltWorker
class DraftSyncWorker @AssistedInject constructor(
    @Assisted appContext: Context,
    @Assisted workerParams: WorkerParameters,
    private val draftDao: DraftDao,
    private val storyRepository: StoryRepository
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {
        Timber.d("Starting draft sync...")

        val unsynced = draftDao.getUnsyncedDrafts()
        if (unsynced.isEmpty()) {
            Timber.d("No unsynced drafts found")
            return Result.success()
        }

        var successCount = 0
        var failCount = 0

        for (draft in unsynced) {
            val result = storyRepository.createStory(
                title = draft.title,
                summary = draft.summary,
                body = draft.body,
                language = Language.fromCode(draft.language),
                sectionId = draft.sectionId,
                tags = emptyList(),
                regions = emptyList(),
                saveAsDraft = true
            )

            when (result) {
                is `in`.newsdarpan.team.util.Result.Success -> {
                    draftDao.markSynced(draft.localId, result.data.id)
                    successCount++
                }
                is `in`.newsdarpan.team.util.Result.Error -> {
                    Timber.w("Failed to sync draft ${draft.localId}: ${result.message}")
                    failCount++
                }
            }
        }

        Timber.d("Draft sync complete: $successCount synced, $failCount failed")
        return if (failCount == 0) Result.success() else Result.retry()
    }

    companion object {
        const val WORK_NAME = "draft_sync"

        fun createRequest(): OneTimeWorkRequest {
            return OneTimeWorkRequestBuilder<DraftSyncWorker>()
                .setConstraints(
                    Constraints.Builder()
                        .setRequiredNetworkType(NetworkType.CONNECTED)
                        .build()
                )
                .setBackoffCriteria(
                    BackoffPolicy.EXPONENTIAL,
                    30, TimeUnit.SECONDS
                )
                .build()
        }

        fun createPeriodicRequest(): PeriodicWorkRequest {
            return PeriodicWorkRequestBuilder<DraftSyncWorker>(
                15, TimeUnit.MINUTES,
                5, TimeUnit.MINUTES
            )
                .setConstraints(
                    Constraints.Builder()
                        .setRequiredNetworkType(NetworkType.CONNECTED)
                        .build()
                )
                .build()
        }
    }
}

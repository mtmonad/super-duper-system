package `in`.newsdarpan.team.data.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class PaginatedResponse<T>(
    val results: List<T>,
    @SerialName("next_cursor") val nextCursor: String? = null,
    val count: Int = 0
)

@Serializable
data class StoryDto(
    val id: Long,
    val title: String,
    val slug: String,
    val summary: String = "",
    val body: String = "",
    val status: String,
    val language: String = "en",
    val section: SectionDto? = null,
    val author: StoryAuthorDto,
    val tags: List<TagDto> = emptyList(),
    val regions: List<RegionDto> = emptyList(),
    val media: List<MediaAssetDto> = emptyList(),
    @SerialName("translation_group_id") val translationGroupId: Long? = null,
    val seo: SeoRecordDto? = null,
    @SerialName("quality_score") val qualityScore: Int? = null,
    @SerialName("risk_tier") val riskTier: String? = null,
    @SerialName("legal_hold") val legalHold: Boolean = false,
    @SerialName("editor_notes") val editorNotes: String? = null,
    @SerialName("created_at") val createdAt: String,
    @SerialName("updated_at") val updatedAt: String,
    @SerialName("published_at") val publishedAt: String? = null
)

@Serializable
data class StoryAuthorDto(
    val id: Long,
    val name: String,
    @SerialName("avatar_url") val avatarUrl: String? = null
)

@Serializable
data class SectionDto(
    val id: Long,
    val name: String,
    val slug: String
)

@Serializable
data class TagDto(
    val id: Long,
    val name: String,
    val slug: String
)

@Serializable
data class RegionDto(
    val id: Long,
    val name: String,
    val slug: String
)

@Serializable
data class MediaAssetDto(
    val id: Long,
    val url: String,
    val type: String = "image",
    val caption: String? = null,
    @SerialName("alt_text") val altText: String? = null,
    val credit: String? = null,
    @SerialName("is_ai_generated") val isAiGenerated: Boolean = false,
    @SerialName("thumbnail_url") val thumbnailUrl: String? = null,
    val width: Int? = null,
    val height: Int? = null,
    @SerialName("file_size") val fileSize: Long? = null,
    @SerialName("uploaded_at") val uploadedAt: String? = null
)

@Serializable
data class SeoRecordDto(
    val title: String = "",
    val description: String = "",
    val keywords: List<String> = emptyList(),
    @SerialName("faq_items") val faqItems: List<FaqItemDto> = emptyList()
)

@Serializable
data class FaqItemDto(
    val question: String,
    val answer: String
)

@Serializable
data class CreateStoryRequest(
    val title: String,
    val summary: String = "",
    val body: String = "",
    val language: String = "en",
    @SerialName("section_id") val sectionId: Long? = null,
    @SerialName("tag_ids") val tagIds: List<Long> = emptyList(),
    @SerialName("region_ids") val regionIds: List<Long> = emptyList(),
    @SerialName("save_as_draft") val saveAsDraft: Boolean = true
)

@Serializable
data class UpdateStoryRequest(
    val title: String? = null,
    val summary: String? = null,
    val body: String? = null,
    @SerialName("section_id") val sectionId: Long? = null,
    @SerialName("tag_ids") val tagIds: List<Long>? = null,
    @SerialName("region_ids") val regionIds: List<Long>? = null
)

@Serializable
data class TransitionRequest(
    val action: String,
    val comment: String? = null
)

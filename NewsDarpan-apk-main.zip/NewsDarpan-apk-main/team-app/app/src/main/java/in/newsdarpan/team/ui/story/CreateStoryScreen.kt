package `in`.newsdarpan.team.ui.story

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import `in`.newsdarpan.team.R
import `in`.newsdarpan.team.domain.model.Language

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateStoryScreen(
    storyId: Long?,
    onNavigateBack: () -> Unit,
    onStorySaved: (Long) -> Unit,
    viewModel: CreateStoryViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    LaunchedEffect(storyId) {
        if (storyId != null) {
            viewModel.loadStory(storyId)
        }
    }

    LaunchedEffect(uiState.savedStoryId) {
        uiState.savedStoryId?.let { id ->
            onStorySaved(id)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        if (storyId != null) stringResource(R.string.edit_story)
                        else stringResource(R.string.create_story)
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    // Save as draft button
                    TextButton(
                        onClick = { viewModel.saveStory(asDraft = true) },
                        enabled = !uiState.isLoading
                    ) {
                        Text(stringResource(R.string.save_draft))
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Language selector
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Language.entries.forEach { language ->
                    FilterChip(
                        selected = uiState.language == language,
                        onClick = { viewModel.onLanguageChange(language) },
                        label = { Text(language.displayName) }
                    )
                }
            }

            // Title
            OutlinedTextField(
                value = uiState.title,
                onValueChange = viewModel::onTitleChange,
                label = { Text(stringResource(R.string.story_title_hint)) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = false,
                maxLines = 3,
                enabled = !uiState.isLoading
            )

            // Summary
            OutlinedTextField(
                value = uiState.summary,
                onValueChange = viewModel::onSummaryChange,
                label = { Text(stringResource(R.string.story_summary_hint)) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = false,
                maxLines = 4,
                enabled = !uiState.isLoading
            )

            // Section dropdown
            var sectionExpanded by remember { mutableStateOf(false) }
            ExposedDropdownMenuBox(
                expanded = sectionExpanded,
                onExpandedChange = { sectionExpanded = it }
            ) {
                OutlinedTextField(
                    value = uiState.selectedSection?.name ?: "",
                    onValueChange = {},
                    readOnly = true,
                    label = { Text(stringResource(R.string.select_section)) },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = sectionExpanded) },
                    modifier = Modifier
                        .menuAnchor()
                        .fillMaxWidth(),
                    enabled = !uiState.isLoading
                )
                ExposedDropdownMenu(
                    expanded = sectionExpanded,
                    onDismissRequest = { sectionExpanded = false }
                ) {
                    uiState.sections.forEach { section ->
                        DropdownMenuItem(
                            text = { Text(section.name) },
                            onClick = {
                                viewModel.onSectionChange(section)
                                sectionExpanded = false
                            }
                        )
                    }
                }
            }

            // Body
            OutlinedTextField(
                value = uiState.body,
                onValueChange = viewModel::onBodyChange,
                label = { Text(stringResource(R.string.story_body_hint)) },
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 200.dp),
                singleLine = false,
                enabled = !uiState.isLoading
            )

            // Media section
            Text(
                text = stringResource(R.string.add_media),
                style = MaterialTheme.typography.titleSmall
            )

            OutlinedButton(
                onClick = { viewModel.onAddMediaClick() },
                modifier = Modifier.fillMaxWidth(),
                enabled = !uiState.isLoading
            ) {
                Icon(Icons.Default.AddPhotoAlternate, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(stringResource(R.string.upload_media))
            }

            // Error message
            if (uiState.error != null) {
                Text(
                    text = uiState.error!!,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall
                )
            }

            // Submit button
            Button(
                onClick = { viewModel.saveStory(asDraft = false) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                enabled = !uiState.isLoading && uiState.title.isNotBlank()
            ) {
                if (uiState.isLoading) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        color = MaterialTheme.colorScheme.onPrimary,
                        strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                }
                Text(stringResource(R.string.submit_for_review))
            }

            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

package `in`.newsdarpan.team.ui.editor

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import `in`.newsdarpan.team.R
import `in`.newsdarpan.team.domain.model.StoryStatus
import `in`.newsdarpan.team.ui.common.components.StoryListItem

/**
 * Editor Queue - shows stories pending review.
 * Only visible to users with REVIEW_STORIES capability (Editor, Administrator, Super Admin).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorQueueScreen(
    onNavigateBack: () -> Unit,
    onStoryClick: (Long) -> Unit,
    viewModel: EditorQueueViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.editor_queue)) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        when {
            uiState.isLoading -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator()
                }
            }
            uiState.error != null -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = uiState.error!!,
                            color = MaterialTheme.colorScheme.error
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(onClick = viewModel::loadQueue) {
                            Text(stringResource(R.string.retry))
                        }
                    }
                }
            }
            uiState.stories.isEmpty() -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No stories pending review",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )
                }
            }
            else -> {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Tab filters
                    item {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            FilterChip(
                                selected = uiState.selectedFilter == StoryStatus.SUBMITTED,
                                onClick = { viewModel.filterByStatus(StoryStatus.SUBMITTED) },
                                label = { Text("Submitted") }
                            )
                            FilterChip(
                                selected = uiState.selectedFilter == StoryStatus.IN_REVIEW,
                                onClick = { viewModel.filterByStatus(StoryStatus.IN_REVIEW) },
                                label = { Text("In Review") }
                            )
                            FilterChip(
                                selected = uiState.selectedFilter == StoryStatus.APPROVED,
                                onClick = { viewModel.filterByStatus(StoryStatus.APPROVED) },
                                label = { Text("Approved") }
                            )
                        }
                    }

                    items(uiState.stories) { story ->
                        StoryListItem(
                            story = story,
                            onClick = { onStoryClick(story.id) }
                        )
                    }
                }
            }
        }
    }
}

package `in`.newsdarpan.team.util

import retrofit2.Response
import timber.log.Timber

/**
 * Safely execute an API call and wrap it in a Result.
 */
suspend fun <T> safeApiCall(
    apiCall: suspend () -> Response<T>
): Result<T> {
    return try {
        val response = apiCall()
        if (response.isSuccessful) {
            val body = response.body()
            if (body != null) {
                Result.Success(body)
            } else {
                Result.Error("Empty response body", response.code())
            }
        } else {
            val errorMsg = when (response.code()) {
                401 -> "Authentication failed. Please login again."
                403 -> "You do not have permission to perform this action."
                404 -> "Resource not found."
                422 -> "Invalid data submitted."
                429 -> "Too many requests. Please try again later."
                in 500..599 -> "Server error. Please try again later."
                else -> "Request failed with code ${response.code()}"
            }
            Timber.e("API error: ${response.code()} - ${response.errorBody()?.string()}")
            Result.Error(errorMsg, response.code())
        }
    } catch (e: Exception) {
        Timber.e(e, "API call failed")
        Result.Error(e.message ?: "Unknown error occurred")
    }
}

package `in`.newsdarpan.team.domain.usecase

import `in`.newsdarpan.team.data.repository.AuthRepository
import `in`.newsdarpan.team.domain.model.User
import `in`.newsdarpan.team.util.Result
import javax.inject.Inject

/**
 * Use case for authenticating a staff user.
 * Only cockpit-registered users are allowed to login.
 */
class LoginUseCase @Inject constructor(
    private val authRepository: AuthRepository
) {
    suspend operator fun invoke(email: String, password: String): Result<User> {
        if (email.isBlank() || password.isBlank()) {
            return Result.Error("Email and password are required")
        }
        return authRepository.login(email, password)
    }
}

/**
 * Use case for logging out the current user.
 */
class LogoutUseCase @Inject constructor(
    private val authRepository: AuthRepository
) {
    suspend operator fun invoke() {
        authRepository.logout()
    }
}

/**
 * Use case for refreshing the auth token.
 */
class RefreshTokenUseCase @Inject constructor(
    private val authRepository: AuthRepository
) {
    suspend operator fun invoke(): Result<Unit> {
        return authRepository.refreshToken()
    }
}

/**
 * Use case for getting the current authenticated user.
 */
class GetCurrentUserUseCase @Inject constructor(
    private val authRepository: AuthRepository
) {
    suspend operator fun invoke(): User? {
        return authRepository.getCurrentUser()
    }
}

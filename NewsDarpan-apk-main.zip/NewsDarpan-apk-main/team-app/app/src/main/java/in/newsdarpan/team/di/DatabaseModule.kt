package `in`.newsdarpan.team.di

import android.content.Context
import androidx.room.Room
import `in`.newsdarpan.team.data.local.DraftDao
import `in`.newsdarpan.team.data.local.DraftDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideDraftDatabase(@ApplicationContext context: Context): DraftDatabase {
        return Room.databaseBuilder(
            context,
            DraftDatabase::class.java,
            "team_drafts.db"
        ).build()
    }

    @Provides
    @Singleton
    fun provideDraftDao(database: DraftDatabase): DraftDao {
        return database.draftDao()
    }
}

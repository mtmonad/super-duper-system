package `in`.newsdarpan.team.di

import `in`.newsdarpan.team.data.api.AuthApi
import `in`.newsdarpan.team.data.api.StaffApi
import `in`.newsdarpan.team.data.local.TokenManager
import `in`.newsdarpan.team.data.repository.AuthRepository
import `in`.newsdarpan.team.data.repository.MediaRepository
import `in`.newsdarpan.team.data.repository.StoryRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object RepositoryModule {

    @Provides
    @Singleton
    fun provideAuthRepository(
        authApi: AuthApi,
        tokenManager: TokenManager
    ): AuthRepository {
        return AuthRepository(authApi, tokenManager)
    }

    @Provides
    @Singleton
    fun provideStoryRepository(staffApi: StaffApi): StoryRepository {
        return StoryRepository(staffApi)
    }

    @Provides
    @Singleton
    fun provideMediaRepository(staffApi: StaffApi): MediaRepository {
        return MediaRepository(staffApi)
    }
}

package `in`.newsdarpan.team.domain.model

/**
 * Represents a workflow action that can be performed on a story.
 * Backend enforces that transitions are valid (e.g., no self-approval).
 */
data class WorkflowTransition(
    val action: TransitionAction,
    val fromStatus: StoryStatus,
    val toStatus: StoryStatus,
    val comment: String? = null
)

enum class TransitionAction(val displayName: String) {
    SUBMIT("Submit for Review"),
    START_REVIEW("Start Review"),
    APPROVE("Approve"),
    REJECT("Reject"),
    PUBLISH("Publish"),
    DEMOTE("Demote"),
    ARCHIVE("Archive"),
    SEND_BACK("Send Back to Author");

    companion object {
        fun fromString(value: String): TransitionAction? {
            return entries.find { it.name.equals(value, ignoreCase = true) }
        }
    }
}

/**
 * Audit log entry for workflow transitions.
 */
data class AuditEntry(
    val id: Long,
    val storyId: Long,
    val storyTitle: String,
    val action: String,
    val actorName: String,
    val actorRole: String,
    val comment: String?,
    val timestamp: String
)

package `in`.newsdarpan.team.data.api

import `in`.newsdarpan.team.data.local.TokenManager
import `in`.newsdarpan.team.data.model.RefreshTokenRequest
import `in`.newsdarpan.team.data.model.TokenResponse
import kotlinx.coroutines.runBlocking
import kotlinx.serialization.json.Json
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import timber.log.Timber
import javax.inject.Inject

/**
 * OkHttp Authenticator that handles automatic token refresh on 401 responses.
 */
class TokenRefreshAuthenticator @Inject constructor(
    private val tokenManager: TokenManager
) : Authenticator {

    private val json = Json { ignoreUnknownKeys = true }

    override fun authenticate(route: Route?, response: Response): Request? {
        // Avoid infinite loop - only retry once
        if (response.request.header("X-Retry-Auth") != null) {
            Timber.w("Token refresh already attempted, not retrying")
            return null
        }

        val refreshToken = runBlocking { tokenManager.getRefreshToken() } ?: run {
            Timber.w("No refresh token available")
            runBlocking { tokenManager.clearAll() }
            return null
        }

        return runBlocking {
            try {
                val refreshBody = json.encodeToString(
                    RefreshTokenRequest.serializer(),
                    RefreshTokenRequest(refreshToken)
                )

                val refreshRequest = Request.Builder()
                    .url("https://newsdarpan.in/api/v1/auth/token/refresh/")
                    .post(refreshBody.toRequestBody("application/json".toMediaType()))
                    .build()

                val client = OkHttpClient()
                val refreshResponse = client.newCall(refreshRequest).execute()

                if (refreshResponse.isSuccessful) {
                    val body = refreshResponse.body?.string()
                    if (body != null) {
                        val tokenResponse = json.decodeFromString(TokenResponse.serializer(), body)
                        tokenManager.saveTokens(tokenResponse.accessToken, tokenResponse.refreshToken)

                        response.request.newBuilder()
                            .header("Authorization", "Bearer ${tokenResponse.accessToken}")
                            .header("X-Retry-Auth", "true")
                            .build()
                    } else {
                        tokenManager.clearAll()
                        null
                    }
                } else {
                    Timber.w("Token refresh failed with code: ${refreshResponse.code}")
                    tokenManager.clearAll()
                    null
                }
            } catch (e: Exception) {
                Timber.e(e, "Token refresh error")
                tokenManager.clearAll()
                null
            }
        }
    }
}

package `in`.newsdarpan.team.ui.story

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import `in`.newsdarpan.team.domain.model.Capability
import `in`.newsdarpan.team.domain.model.StoryStatus
import `in`.newsdarpan.team.domain.model.TransitionAction
import `in`.newsdarpan.team.ui.common.components.StatusChip

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StoryDetailScreen(
    storyId: Long,
    onNavigateBack: () -> Unit,
    onEditStory: () -> Unit,
    onGenerateVideo: () -> Unit,
    viewModel: StoryDetailViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    LaunchedEffect(storyId) {
        viewModel.loadStory(storyId)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Story Details") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    if (uiState.canEdit) {
                        IconButton(onClick = onEditStory) {
                            Icon(Icons.Default.Edit, contentDescription = "Edit")
                        }
                    }
                    if (uiState.canGenerateVideo) {
                        IconButton(onClick = onGenerateVideo) {
                            Icon(Icons.Default.VideoCall, contentDescription = "Generate Video")
                        }
                    }
                }
            )
        }
    ) { padding ->
        when {
            uiState.isLoading -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator()
                }
            }
            uiState.error != null -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = uiState.error!!,
                        color = MaterialTheme.colorScheme.error
                    )
                }
            }
            uiState.story != null -> {
                val story = uiState.story!!
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding)
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Status and metadata
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        StatusChip(status = story.status)
                        Text(
                            text = story.language.displayName,
                            style = MaterialTheme.typography.labelMedium
                        )
                    }

                    // Title
                    Text(
                        text = story.title,
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )

                    // Author and section
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "By ${story.author.name}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                        )
                        story.section?.let { section ->
                            AssistChip(
                                onClick = {},
                                label = { Text(section.name) }
                            )
                        }
                    }

                    // Summary
                    if (story.summary.isNotBlank()) {
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant
                            )
                        ) {
                            Text(
                                text = story.summary,
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    }

                    // Body
                    if (story.body.isNotBlank()) {
                        Text(
                            text = story.body,
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }

                    // Quality and SEO info (for editors)
                    story.qualityScore?.let { score ->
                        Card {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "Quality Score: $score/100",
                                    style = MaterialTheme.typography.titleSmall
                                )
                                story.riskTier?.let { tier ->
                                    Text(
                                        text = "Risk Tier: ${tier.name}",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                            }
                        }
                    }

                    // Editor notes
                    story.editorNotes?.let { notes ->
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.errorContainer
                            )
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "Editor Notes",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = notes,
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                    }

                    // Workflow action buttons
                    if (uiState.availableActions.isNotEmpty()) {
                        HorizontalDivider()
                        Text(
                            text = "Actions",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            uiState.availableActions.forEach { action ->
                                val isDestructive = action == TransitionAction.REJECT ||
                                    action == TransitionAction.DEMOTE
                                Button(
                                    onClick = { viewModel.performTransition(action) },
                                    colors = if (isDestructive) {
                                        ButtonDefaults.buttonColors(
                                            containerColor = MaterialTheme.colorScheme.error
                                        )
                                    } else {
                                        ButtonDefaults.buttonColors()
                                    },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text(
                                        text = action.displayName,
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(32.dp))
                }
            }
        }
    }
}

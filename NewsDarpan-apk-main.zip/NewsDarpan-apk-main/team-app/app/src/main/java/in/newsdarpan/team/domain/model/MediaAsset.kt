package `in`.newsdarpan.team.domain.model

/**
 * MediaAsset represents an image or video attached to a story.
 */
data class MediaAsset(
    val id: Long,
    val url: String,
    val type: MediaType,
    val caption: String? = null,
    val altText: String? = null,
    val credit: String? = null,
    val isAiGenerated: Boolean = false,
    val thumbnailUrl: String? = null,
    val width: Int? = null,
    val height: Int? = null,
    val fileSize: Long? = null,
    val uploadedAt: String? = null
)

enum class MediaType {
    IMAGE, VIDEO, DOCUMENT;

    companion object {
        fun fromString(value: String): MediaType {
            return entries.find { it.name.equals(value, ignoreCase = true) } ?: IMAGE
        }
    }
}

package `in`.newsdarpan.team.domain.usecase

import `in`.newsdarpan.team.data.repository.MediaRepository
import `in`.newsdarpan.team.domain.model.MediaAsset
import `in`.newsdarpan.team.util.Result
import java.io.File
import javax.inject.Inject

/**
 * Use case for uploading media to a story.
 * Available to users with UPLOAD_MEDIA capability.
 */
class UploadMediaUseCase @Inject constructor(
    private val mediaRepository: MediaRepository
) {
    suspend operator fun invoke(
        storyId: Long,
        file: File,
        caption: String?,
        altText: String?,
        credit: String?,
        isAiGenerated: Boolean = false
    ): Result<MediaAsset> {
        if (!file.exists()) {
            return Result.Error("File does not exist")
        }
        return mediaRepository.uploadMedia(storyId, file, caption, altText, credit, isAiGenerated)
    }
}

/**
 * Use case for deleting a media asset from a story.
 */
class DeleteMediaUseCase @Inject constructor(
    private val mediaRepository: MediaRepository
) {
    suspend operator fun invoke(storyId: Long, mediaId: Long): Result<Unit> {
        return mediaRepository.deleteMedia(storyId, mediaId)
    }
}

/**
 * Use case for generating video from a story.
 * Only available to users with GENERATE_VIDEO capability (Editor and Administrator roles).
 */
class GenerateVideoUseCase @Inject constructor(
    private val mediaRepository: MediaRepository
) {
    suspend operator fun invoke(storyId: Long): Result<MediaAsset> {
        return mediaRepository.generateVideo(storyId)
    }
}

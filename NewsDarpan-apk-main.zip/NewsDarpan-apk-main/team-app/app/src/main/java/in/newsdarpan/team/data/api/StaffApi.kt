package `in`.newsdarpan.team.data.api

import `in`.newsdarpan.team.data.model.*
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Response
import retrofit2.http.*

/**
 * Staff API for team operations.
 * Namespace: /api/staff/v1/
 * All endpoints require JWT authentication and role-based capabilities.
 */
interface StaffApi {

    // --- Stories ---

    @GET("api/staff/v1/stories/")
    suspend fun getStories(
        @Query("status") status: String? = null,
        @Query("author") authorId: Long? = null,
        @Query("section") sectionId: Long? = null,
        @Query("cursor") cursor: String? = null,
        @Query("page_size") pageSize: Int = 20
    ): Response<PaginatedResponse<StoryDto>>

    @GET("api/staff/v1/stories/{id}/")
    suspend fun getStoryDetail(@Path("id") storyId: Long): Response<StoryDto>

    @POST("api/staff/v1/stories/")
    suspend fun createStory(@Body request: CreateStoryRequest): Response<StoryDto>

    @PATCH("api/staff/v1/stories/{id}/")
    suspend fun updateStory(
        @Path("id") storyId: Long,
        @Body request: UpdateStoryRequest
    ): Response<StoryDto>

    @DELETE("api/staff/v1/stories/{id}/")
    suspend fun deleteStory(@Path("id") storyId: Long): Response<Unit>

    @GET("api/staff/v1/stories/search/")
    suspend fun searchStories(
        @Query("q") query: String,
        @Query("cursor") cursor: String? = null
    ): Response<PaginatedResponse<StoryDto>>

    // --- Workflow Transitions ---

    @POST("api/staff/v1/stories/{id}/transitions/")
    suspend fun transitionStory(
        @Path("id") storyId: Long,
        @Body request: TransitionRequest
    ): Response<StoryDto>

    // --- Media ---

    @Multipart
    @POST("api/staff/v1/stories/{id}/media/")
    suspend fun uploadMedia(
        @Path("id") storyId: Long,
        @Part file: MultipartBody.Part,
        @Part("caption") caption: RequestBody?,
        @Part("alt_text") altText: RequestBody?,
        @Part("credit") credit: RequestBody?,
        @Part("is_ai_generated") isAiGenerated: RequestBody?
    ): Response<MediaAssetDto>

    @DELETE("api/staff/v1/stories/{storyId}/media/{mediaId}/")
    suspend fun deleteMedia(
        @Path("storyId") storyId: Long,
        @Path("mediaId") mediaId: Long
    ): Response<Unit>

    // --- Video Generation (Editor & Administrator only) ---

    @POST("api/staff/v1/stories/{id}/generate-video/")
    suspend fun generateVideo(@Path("id") storyId: Long): Response<MediaAssetDto>

    // --- Reporters (Admin only) ---

    @GET("api/staff/v1/reporters/")
    suspend fun getReporters(
        @Query("cursor") cursor: String? = null
    ): Response<PaginatedResponse<UserDto>>

    // --- Sections ---

    @GET("api/staff/v1/sections/")
    suspend fun getSections(): Response<List<SectionDto>>

    // --- Audit Log (Admin only) ---

    @GET("api/staff/v1/audit/")
    suspend fun getAuditLog(
        @Query("cursor") cursor: String? = null,
        @Query("story_id") storyId: Long? = null,
        @Query("actor_id") actorId: Long? = null
    ): Response<PaginatedResponse<AuditEntryDto>>

    // --- Dashboard Stats ---

    @GET("api/staff/v1/dashboard/")
    suspend fun getDashboardStats(): Response<DashboardStatsDto>
}

package `in`.newsdarpan.team.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

/**
 * Room database for offline draft storage.
 * Drafts are stored locally when user creates stories offline.
 */
@Database(
    entities = [DraftEntity::class],
    version = 1,
    exportSchema = false
)
abstract class DraftDatabase : RoomDatabase() {
    abstract fun draftDao(): DraftDao
}

@Entity(tableName = "drafts")
data class DraftEntity(
    @PrimaryKey(autoGenerate = true) val localId: Long = 0,
    val remoteId: Long? = null,
    val title: String,
    val summary: String = "",
    val body: String = "",
    val language: String = "en",
    val sectionId: Long? = null,
    val tags: String = "", // JSON array stored as string
    val regions: String = "", // JSON array stored as string
    val isSynced: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Dao
interface DraftDao {

    @Query("SELECT * FROM drafts ORDER BY updatedAt DESC")
    fun getAllDrafts(): Flow<List<DraftEntity>>

    @Query("SELECT * FROM drafts WHERE isSynced = 0")
    suspend fun getUnsyncedDrafts(): List<DraftEntity>

    @Query("SELECT * FROM drafts WHERE localId = :localId")
    suspend fun getDraftById(localId: Long): DraftEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDraft(draft: DraftEntity): Long

    @Update
    suspend fun updateDraft(draft: DraftEntity)

    @Query("UPDATE drafts SET isSynced = 1, remoteId = :remoteId WHERE localId = :localId")
    suspend fun markSynced(localId: Long, remoteId: Long)

    @Delete
    suspend fun deleteDraft(draft: DraftEntity)

    @Query("DELETE FROM drafts WHERE localId = :localId")
    suspend fun deleteDraftById(localId: Long)
}

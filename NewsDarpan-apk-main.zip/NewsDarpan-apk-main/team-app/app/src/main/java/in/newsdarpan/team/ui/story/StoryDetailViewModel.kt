package `in`.newsdarpan.team.ui.story

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import `in`.newsdarpan.team.data.repository.AuthRepository
import `in`.newsdarpan.team.domain.model.*
import `in`.newsdarpan.team.domain.usecase.GetStoryDetailUseCase
import `in`.newsdarpan.team.domain.usecase.TransitionStoryUseCase
import `in`.newsdarpan.team.util.Result
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class StoryDetailUiState(
    val story: Story? = null,
    val isLoading: Boolean = true,
    val error: String? = null,
    val canEdit: Boolean = false,
    val canGenerateVideo: Boolean = false,
    val availableActions: List<TransitionAction> = emptyList()
)

@HiltViewModel
class StoryDetailViewModel @Inject constructor(
    private val getStoryDetailUseCase: GetStoryDetailUseCase,
    private val transitionStoryUseCase: TransitionStoryUseCase,
    private val authRepository: AuthRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(StoryDetailUiState())
    val uiState: StateFlow<StoryDetailUiState> = _uiState.asStateFlow()

    fun loadStory(storyId: Long) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }

            val user = authRepository.getCurrentUser()
            val capabilities = user?.capabilities ?: emptyList()

            when (val result = getStoryDetailUseCase(storyId)) {
                is Result.Success -> {
                    val story = result.data
                    val actions = getAvailableActions(story, capabilities, user)
                    val canEdit = capabilities.contains(Capability.EDIT_OWN_STORY) &&
                        story.status in listOf(StoryStatus.DRAFT, StoryStatus.REJECTED)
                    val canVideo = capabilities.contains(Capability.GENERATE_VIDEO)

                    _uiState.update {
                        it.copy(
                            story = story,
                            isLoading = false,
                            canEdit = canEdit,
                            canGenerateVideo = canVideo,
                            availableActions = actions
                        )
                    }
                }
                is Result.Error -> {
                    _uiState.update { it.copy(isLoading = false, error = result.message) }
                }
            }
        }
    }

    private fun getAvailableActions(
        story: Story,
        capabilities: List<Capability>,
        user: User?
    ): List<TransitionAction> {
        val actions = mutableListOf<TransitionAction>()

        when (story.status) {
            StoryStatus.DRAFT -> {
                if (capabilities.contains(Capability.CREATE_STORY)) {
                    actions.add(TransitionAction.SUBMIT)
                }
            }
            StoryStatus.SUBMITTED -> {
                if (capabilities.contains(Capability.REVIEW_STORIES)) {
                    actions.add(TransitionAction.START_REVIEW)
                }
            }
            StoryStatus.IN_REVIEW -> {
                if (capabilities.contains(Capability.APPROVE_STORIES)) {
                    actions.add(TransitionAction.APPROVE)
                }
                if (capabilities.contains(Capability.REJECT_STORIES)) {
                    actions.add(TransitionAction.REJECT)
                    actions.add(TransitionAction.SEND_BACK)
                }
            }
            StoryStatus.APPROVED -> {
                if (capabilities.contains(Capability.PUBLISH_STORIES)) {
                    actions.add(TransitionAction.PUBLISH)
                }
            }
            StoryStatus.PUBLISHED -> {
                if (capabilities.contains(Capability.PUBLISH_STORIES)) {
                    actions.add(TransitionAction.DEMOTE)
                }
            }
            else -> { /* No actions for other states */ }
        }

        return actions
    }

    fun performTransition(action: TransitionAction) {
        val story = _uiState.value.story ?: return

        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }

            when (val result = transitionStoryUseCase(story.id, action)) {
                is Result.Success -> {
                    loadStory(story.id)
                }
                is Result.Error -> {
                    _uiState.update { it.copy(isLoading = false, error = result.message) }
                }
            }
        }
    }
}

package `in`.newsdarpan.team.ui.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import `in`.newsdarpan.team.data.model.DashboardStatsDto
import `in`.newsdarpan.team.data.repository.AuthRepository
import `in`.newsdarpan.team.data.repository.StoryRepository
import `in`.newsdarpan.team.domain.model.*
import `in`.newsdarpan.team.domain.usecase.GetStoriesUseCase
import `in`.newsdarpan.team.util.Result
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class DashboardUiState(
    val user: User? = null,
    val stats: DashboardStatsDto? = null,
    val recentStories: List<Story> = emptyList(),
    val isLoading: Boolean = true,
    val error: String? = null,
    val hasEditorAccess: Boolean = false,
    val hasAdminAccess: Boolean = false,
    val hasVideoAccess: Boolean = false
)

@HiltViewModel
class DashboardViewModel @Inject constructor(
    private val authRepository: AuthRepository,
    private val storyRepository: StoryRepository,
    private val getStoriesUseCase: GetStoriesUseCase
) : ViewModel() {

    private val _uiState = MutableStateFlow(DashboardUiState())
    val uiState: StateFlow<DashboardUiState> = _uiState.asStateFlow()

    init {
        loadDashboard()
    }

    fun loadDashboard() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }

            // Load user info
            val user = authRepository.getCurrentUser()
            val hasEditor = user?.capabilities?.contains(Capability.REVIEW_STORIES) == true
            val hasAdmin = user?.capabilities?.contains(Capability.MANAGE_REPORTERS) == true
            val hasVideo = user?.capabilities?.contains(Capability.GENERATE_VIDEO) == true

            _uiState.update {
                it.copy(
                    user = user,
                    hasEditorAccess = hasEditor,
                    hasAdminAccess = hasAdmin,
                    hasVideoAccess = hasVideo
                )
            }

            // Load dashboard stats
            when (val statsResult = storyRepository.getDashboardStats()) {
                is Result.Success -> {
                    _uiState.update { it.copy(stats = statsResult.data) }
                }
                is Result.Error -> {
                    // Stats are non-critical, continue loading
                }
            }

            // Load recent stories
            when (val storiesResult = getStoriesUseCase(authorId = user?.id)) {
                is Result.Success -> {
                    _uiState.update {
                        it.copy(
                            recentStories = storiesResult.data.stories,
                            isLoading = false
                        )
                    }
                }
                is Result.Error -> {
                    _uiState.update {
                        it.copy(isLoading = false, error = storiesResult.message)
                    }
                }
            }
        }
    }
}

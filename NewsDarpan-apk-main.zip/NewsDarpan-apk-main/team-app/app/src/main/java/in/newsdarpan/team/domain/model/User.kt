package `in`.newsdarpan.team.domain.model

/**
 * Represents a staff user with their role and capabilities.
 * Only users registered on newsdarpan.in/cockpit are allowed.
 */
data class User(
    val id: Long,
    val email: String,
    val fullName: String,
    val role: UserRole,
    val capabilities: List<Capability>,
    val avatarUrl: String? = null,
    val isActive: Boolean = true
)

/**
 * User roles in the system hierarchy.
 * Each role has specific capabilities that determine what actions are available in the app.
 */
enum class UserRole(val displayName: String, val level: Int) {
    FIELD_REPORTER("Field Reporter", 1),
    DESK_REPORTER("Desk Reporter", 2),
    SUB_EDITOR("Sub Editor", 3),
    EDITOR("Editor", 4),
    LEGAL_REVIEWER("Legal Reviewer", 4),
    ADMINISTRATOR("Administrator", 5),
    SUPER_ADMIN("Super Admin", 6);

    companion object {
        fun fromString(value: String): UserRole {
            return entries.find {
                it.name.equals(value, ignoreCase = true) ||
                it.name.replace("_", "").equals(value.replace("_", ""), ignoreCase = true)
            } ?: FIELD_REPORTER
        }
    }
}

/**
 * Granular capabilities controlling specific actions.
 * Backend enforces these server-side; the app uses them for UI gating.
 */
enum class Capability {
    // Content creation
    CREATE_STORY,
    EDIT_OWN_STORY,
    UPLOAD_MEDIA,

    // Review and approval
    REVIEW_STORIES,
    APPROVE_STORIES,
    REJECT_STORIES,
    PUBLISH_STORIES,

    // Advanced content
    GENERATE_VIDEO,
    EDIT_SEO,
    MANAGE_TRANSLATIONS,

    // Moderation
    MODERATE_COMMENTS,
    MANAGE_LIVE_UPDATES,

    // Administration
    MANAGE_REPORTERS,
    VIEW_AUDIT_LOG,
    MANAGE_NOTIFICATIONS,
    MANAGE_SECTIONS,
    OVERRIDE_POLICY,

    // Super admin
    MANAGE_ROLES,
    SYSTEM_SETTINGS;

    companion object {
        fun fromString(value: String): Capability? {
            return entries.find { it.name.equals(value, ignoreCase = true) }
        }
    }
}

/**
 * Default capabilities for each role.
 * These are the baseline; the backend may grant additional capabilities.
 */
fun UserRole.defaultCapabilities(): Set<Capability> = when (this) {
    UserRole.FIELD_REPORTER -> setOf(
        Capability.CREATE_STORY,
        Capability.EDIT_OWN_STORY,
        Capability.UPLOAD_MEDIA
    )
    UserRole.DESK_REPORTER -> setOf(
        Capability.CREATE_STORY,
        Capability.EDIT_OWN_STORY,
        Capability.UPLOAD_MEDIA
    )
    UserRole.SUB_EDITOR -> setOf(
        Capability.CREATE_STORY,
        Capability.EDIT_OWN_STORY,
        Capability.UPLOAD_MEDIA,
        Capability.REVIEW_STORIES,
        Capability.EDIT_SEO
    )
    UserRole.EDITOR -> setOf(
        Capability.CREATE_STORY,
        Capability.EDIT_OWN_STORY,
        Capability.UPLOAD_MEDIA,
        Capability.REVIEW_STORIES,
        Capability.APPROVE_STORIES,
        Capability.REJECT_STORIES,
        Capability.PUBLISH_STORIES,
        Capability.GENERATE_VIDEO,
        Capability.EDIT_SEO,
        Capability.MANAGE_TRANSLATIONS,
        Capability.MODERATE_COMMENTS,
        Capability.MANAGE_LIVE_UPDATES
    )
    UserRole.LEGAL_REVIEWER -> setOf(
        Capability.REVIEW_STORIES,
        Capability.APPROVE_STORIES,
        Capability.REJECT_STORIES
    )
    UserRole.ADMINISTRATOR -> setOf(
        Capability.CREATE_STORY,
        Capability.EDIT_OWN_STORY,
        Capability.UPLOAD_MEDIA,
        Capability.REVIEW_STORIES,
        Capability.APPROVE_STORIES,
        Capability.REJECT_STORIES,
        Capability.PUBLISH_STORIES,
        Capability.GENERATE_VIDEO,
        Capability.EDIT_SEO,
        Capability.MANAGE_TRANSLATIONS,
        Capability.MODERATE_COMMENTS,
        Capability.MANAGE_LIVE_UPDATES,
        Capability.MANAGE_REPORTERS,
        Capability.VIEW_AUDIT_LOG,
        Capability.MANAGE_NOTIFICATIONS,
        Capability.MANAGE_SECTIONS
    )
    UserRole.SUPER_ADMIN -> Capability.entries.toSet()
}

package `in`.newsdarpan.team.data.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class UserDto(
    val id: Long,
    val email: String,
    @SerialName("full_name") val fullName: String,
    val role: String,
    val capabilities: List<String> = emptyList(),
    @SerialName("avatar_url") val avatarUrl: String? = null,
    @SerialName("is_active") val isActive: Boolean = true
)

@Serializable
data class AuditEntryDto(
    val id: Long,
    @SerialName("story_id") val storyId: Long,
    @SerialName("story_title") val storyTitle: String,
    val action: String,
    @SerialName("actor_name") val actorName: String,
    @SerialName("actor_role") val actorRole: String,
    val comment: String? = null,
    val timestamp: String
)

@Serializable
data class DashboardStatsDto(
    @SerialName("my_stories_count") val myStoriesCount: Int = 0,
    @SerialName("pending_review_count") val pendingReviewCount: Int = 0,
    @SerialName("published_today_count") val publishedTodayCount: Int = 0,
    @SerialName("drafts_count") val draftsCount: Int = 0,
    @SerialName("total_published_count") val totalPublishedCount: Int = 0,
    @SerialName("queue_aging_hours") val queueAgingHours: Double = 0.0
)

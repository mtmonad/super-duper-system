package `in`.newsdarpan.team.util

/**
 * A sealed class representing either success or failure of an operation.
 */
sealed class Result<out T> {
    data class Success<T>(val data: T) : Result<T>()
    data class Error(val message: String, val code: Int? = null) : Result<Nothing>()

    val isSuccess: Boolean get() = this is Success
    val isError: Boolean get() = this is Error

    fun getOrNull(): T? = when (this) {
        is Success -> data
        is Error -> null
    }

    fun errorMessageOrNull(): String? = when (this) {
        is Success -> null
        is Error -> message
    }

    companion object {
        fun <T> success(data: T): Result<T> = Success(data)
        fun error(message: String, code: Int? = null): Result<Nothing> = Error(message, code)
    }
}

/**
 * Maps a successful result to a new type.
 */
inline fun <T, R> Result<T>.map(transform: (T) -> R): Result<R> = when (this) {
    is Result.Success -> Result.Success(transform(data))
    is Result.Error -> this
}

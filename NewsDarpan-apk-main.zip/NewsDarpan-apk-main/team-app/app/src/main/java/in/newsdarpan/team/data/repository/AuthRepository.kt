package `in`.newsdarpan.team.data.repository

import `in`.newsdarpan.team.data.api.AuthApi
import `in`.newsdarpan.team.data.local.TokenManager
import `in`.newsdarpan.team.data.model.*
import `in`.newsdarpan.team.domain.model.Capability
import `in`.newsdarpan.team.domain.model.User
import `in`.newsdarpan.team.domain.model.UserRole
import `in`.newsdarpan.team.util.Result
import `in`.newsdarpan.team.util.safeApiCall
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Repository handling authentication against the cockpit backend.
 * Only registered cockpit users can authenticate.
 */
@Singleton
class AuthRepository @Inject constructor(
    private val authApi: AuthApi,
    private val tokenManager: TokenManager
) {

    /**
     * Authenticate staff user with email and password.
     * POST https://newsdarpan.in/api/v1/auth/token/
     */
    suspend fun login(email: String, password: String): Result<User> {
        val tokenResult = safeApiCall {
            authApi.login(LoginRequest(email = email, password = password))
        }

        return when (tokenResult) {
            is Result.Success -> {
                tokenManager.saveTokens(
                    accessToken = tokenResult.data.accessToken,
                    refreshToken = tokenResult.data.refreshToken
                )
                // Fetch user profile after successful auth
                fetchAndCacheUser()
            }
            is Result.Error -> {
                Timber.e("Login failed: ${tokenResult.message}")
                Result.Error(
                    if (tokenResult.code == 401) "Invalid email or password"
                    else tokenResult.message
                )
            }
        }
    }

    /**
     * Fetch the current user profile from /api/staff/v1/me/
     */
    private suspend fun fetchAndCacheUser(): Result<User> {
        val userResult = safeApiCall { authApi.getCurrentUser() }
        return when (userResult) {
            is Result.Success -> {
                val userDto = userResult.data
                val user = userDto.toDomain()
                tokenManager.saveUserInfo(
                    id = user.id,
                    email = user.email,
                    name = user.fullName,
                    role = user.role.name,
                    capabilities = user.capabilities.map { it.name }
                )
                Result.Success(user)
            }
            is Result.Error -> {
                Timber.e("Failed to fetch user profile: ${userResult.message}")
                userResult
            }
        }
    }

    /**
     * Refresh the JWT access token using the stored refresh token.
     */
    suspend fun refreshToken(): Result<Unit> {
        val refreshToken = tokenManager.getRefreshToken()
            ?: return Result.Error("No refresh token available")

        val result = safeApiCall {
            authApi.refreshToken(RefreshTokenRequest(refreshToken))
        }

        return when (result) {
            is Result.Success -> {
                tokenManager.saveTokens(
                    accessToken = result.data.accessToken,
                    refreshToken = result.data.refreshToken
                )
                Result.Success(Unit)
            }
            is Result.Error -> {
                if (result.code == 401) {
                    // Refresh token is invalid, user must re-login
                    tokenManager.clearAll()
                }
                Result.Error(result.message)
            }
        }
    }

    /**
     * Get the current user from cached info.
     */
    suspend fun getCurrentUser(): User? {
        val id = tokenManager.getUserId() ?: return null
        val role = tokenManager.getUserRole() ?: return null
        val capabilities = tokenManager.getUserCapabilities()

        return User(
            id = id,
            email = "", // Will be populated on next fetch
            fullName = "",
            role = UserRole.fromString(role),
            capabilities = capabilities.mapNotNull { Capability.fromString(it) }
        )
    }

    /**
     * Clear all tokens and user data.
     */
    suspend fun logout() {
        tokenManager.clearAll()
    }

    /**
     * Check if user is currently authenticated.
     */
    suspend fun isAuthenticated(): Boolean {
        return tokenManager.getAccessToken() != null
    }
}

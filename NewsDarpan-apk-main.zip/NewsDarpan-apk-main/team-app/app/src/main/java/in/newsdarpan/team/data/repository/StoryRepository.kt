package `in`.newsdarpan.team.data.repository

import `in`.newsdarpan.team.data.api.StaffApi
import `in`.newsdarpan.team.data.model.*
import `in`.newsdarpan.team.domain.model.*
import `in`.newsdarpan.team.domain.usecase.PaginatedStories
import `in`.newsdarpan.team.util.Result
import `in`.newsdarpan.team.util.safeApiCall
import `in`.newsdarpan.team.util.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class StoryRepository @Inject constructor(
    private val staffApi: StaffApi
) {

    suspend fun getStories(
        status: StoryStatus? = null,
        authorId: Long? = null,
        sectionId: Long? = null,
        cursor: String? = null
    ): Result<PaginatedStories> {
        val result = safeApiCall {
            staffApi.getStories(
                status = status?.name?.lowercase(),
                authorId = authorId,
                sectionId = sectionId,
                cursor = cursor
            )
        }
        return result.map { response ->
            PaginatedStories(
                stories = response.results.map { it.toDomain() },
                nextCursor = response.nextCursor,
                totalCount = response.count
            )
        }
    }

    suspend fun getStoryDetail(storyId: Long): Result<Story> {
        val result = safeApiCall { staffApi.getStoryDetail(storyId) }
        return result.map { it.toDomain() }
    }

    suspend fun createStory(
        title: String,
        summary: String,
        body: String,
        language: Language,
        sectionId: Long?,
        tags: List<Long>,
        regions: List<Long>,
        saveAsDraft: Boolean
    ): Result<Story> {
        val request = CreateStoryRequest(
            title = title,
            summary = summary,
            body = body,
            language = language.code,
            sectionId = sectionId,
            tagIds = tags,
            regionIds = regions,
            saveAsDraft = saveAsDraft
        )
        val result = safeApiCall { staffApi.createStory(request) }
        return result.map { it.toDomain() }
    }

    suspend fun updateStory(
        storyId: Long,
        title: String?,
        summary: String?,
        body: String?,
        sectionId: Long?,
        tags: List<Long>?,
        regions: List<Long>?
    ): Result<Story> {
        val request = UpdateStoryRequest(
            title = title,
            summary = summary,
            body = body,
            sectionId = sectionId,
            tagIds = tags,
            regionIds = regions
        )
        val result = safeApiCall { staffApi.updateStory(storyId, request) }
        return result.map { it.toDomain() }
    }

    suspend fun transitionStory(
        storyId: Long,
        action: TransitionAction,
        comment: String?
    ): Result<Story> {
        val request = TransitionRequest(
            action = action.name.lowercase(),
            comment = comment
        )
        val result = safeApiCall { staffApi.transitionStory(storyId, request) }
        return result.map { it.toDomain() }
    }

    suspend fun searchStories(query: String, cursor: String?): Result<PaginatedStories> {
        val result = safeApiCall { staffApi.searchStories(query, cursor) }
        return result.map { response ->
            PaginatedStories(
                stories = response.results.map { it.toDomain() },
                nextCursor = response.nextCursor,
                totalCount = response.count
            )
        }
    }

    suspend fun getSections(): Result<List<Section>> {
        val result = safeApiCall { staffApi.getSections() }
        return result.map { sections -> sections.map { it.toDomain() } }
    }

    suspend fun getDashboardStats(): Result<DashboardStatsDto> {
        return safeApiCall { staffApi.getDashboardStats() }
    }
}

package `in`.newsdarpan.team.ui.editor

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import `in`.newsdarpan.team.domain.model.Story
import `in`.newsdarpan.team.domain.model.StoryStatus
import `in`.newsdarpan.team.domain.usecase.GetStoriesUseCase
import `in`.newsdarpan.team.util.Result
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class EditorQueueUiState(
    val stories: List<Story> = emptyList(),
    val selectedFilter: StoryStatus = StoryStatus.SUBMITTED,
    val isLoading: Boolean = true,
    val error: String? = null
)

@HiltViewModel
class EditorQueueViewModel @Inject constructor(
    private val getStoriesUseCase: GetStoriesUseCase
) : ViewModel() {

    private val _uiState = MutableStateFlow(EditorQueueUiState())
    val uiState: StateFlow<EditorQueueUiState> = _uiState.asStateFlow()

    init {
        loadQueue()
    }

    fun loadQueue() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            val status = _uiState.value.selectedFilter
            when (val result = getStoriesUseCase(status = status)) {
                is Result.Success -> {
                    _uiState.update {
                        it.copy(stories = result.data.stories, isLoading = false)
                    }
                }
                is Result.Error -> {
                    _uiState.update { it.copy(isLoading = false, error = result.message) }
                }
            }
        }
    }

    fun filterByStatus(status: StoryStatus) {
        _uiState.update { it.copy(selectedFilter = status) }
        loadQueue()
    }
}

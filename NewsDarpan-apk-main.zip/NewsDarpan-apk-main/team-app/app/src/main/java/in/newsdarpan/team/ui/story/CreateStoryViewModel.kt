package `in`.newsdarpan.team.ui.story

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import `in`.newsdarpan.team.data.repository.StoryRepository
import `in`.newsdarpan.team.domain.model.Language
import `in`.newsdarpan.team.domain.model.Section
import `in`.newsdarpan.team.domain.usecase.CreateStoryUseCase
import `in`.newsdarpan.team.domain.usecase.GetStoryDetailUseCase
import `in`.newsdarpan.team.domain.usecase.UpdateStoryUseCase
import `in`.newsdarpan.team.util.Result
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class CreateStoryUiState(
    val title: String = "",
    val summary: String = "",
    val body: String = "",
    val language: Language = Language.HINDI,
    val selectedSection: Section? = null,
    val sections: List<Section> = emptyList(),
    val isEditing: Boolean = false,
    val editStoryId: Long? = null,
    val isLoading: Boolean = false,
    val error: String? = null,
    val savedStoryId: Long? = null
)

@HiltViewModel
class CreateStoryViewModel @Inject constructor(
    private val createStoryUseCase: CreateStoryUseCase,
    private val updateStoryUseCase: UpdateStoryUseCase,
    private val getStoryDetailUseCase: GetStoryDetailUseCase,
    private val storyRepository: StoryRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(CreateStoryUiState())
    val uiState: StateFlow<CreateStoryUiState> = _uiState.asStateFlow()

    init {
        loadSections()
    }

    private fun loadSections() {
        viewModelScope.launch {
            when (val result = storyRepository.getSections()) {
                is Result.Success -> {
                    _uiState.update { it.copy(sections = result.data) }
                }
                is Result.Error -> { /* Non-critical */ }
            }
        }
    }

    fun loadStory(storyId: Long) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            when (val result = getStoryDetailUseCase(storyId)) {
                is Result.Success -> {
                    val story = result.data
                    _uiState.update {
                        it.copy(
                            title = story.title,
                            summary = story.summary,
                            body = story.body,
                            language = story.language,
                            selectedSection = story.section,
                            isEditing = true,
                            editStoryId = storyId,
                            isLoading = false
                        )
                    }
                }
                is Result.Error -> {
                    _uiState.update { it.copy(isLoading = false, error = result.message) }
                }
            }
        }
    }

    fun onTitleChange(title: String) {
        _uiState.update { it.copy(title = title, error = null) }
    }

    fun onSummaryChange(summary: String) {
        _uiState.update { it.copy(summary = summary) }
    }

    fun onBodyChange(body: String) {
        _uiState.update { it.copy(body = body) }
    }

    fun onLanguageChange(language: Language) {
        _uiState.update { it.copy(language = language) }
    }

    fun onSectionChange(section: Section) {
        _uiState.update { it.copy(selectedSection = section) }
    }

    fun onAddMediaClick() {
        // Media upload will be triggered from the UI layer
    }

    fun saveStory(asDraft: Boolean) {
        val state = _uiState.value
        if (state.title.isBlank()) {
            _uiState.update { it.copy(error = "Title is required") }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }

            val result = if (state.isEditing && state.editStoryId != null) {
                updateStoryUseCase(
                    storyId = state.editStoryId,
                    title = state.title,
                    summary = state.summary,
                    body = state.body,
                    sectionId = state.selectedSection?.id
                )
            } else {
                createStoryUseCase(
                    title = state.title,
                    summary = state.summary,
                    body = state.body,
                    language = state.language,
                    sectionId = state.selectedSection?.id,
                    saveAsDraft = asDraft
                )
            }

            when (result) {
                is Result.Success -> {
                    _uiState.update {
                        it.copy(isLoading = false, savedStoryId = result.data.id)
                    }
                }
                is Result.Error -> {
                    _uiState.update { it.copy(isLoading = false, error = result.message) }
                }
            }
        }
    }
}

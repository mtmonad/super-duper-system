package `in`.newsdarpan.team.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import `in`.newsdarpan.team.ui.admin.AdminScreen
import `in`.newsdarpan.team.ui.admin.AuditLogScreen
import `in`.newsdarpan.team.ui.admin.ReporterRosterScreen
import `in`.newsdarpan.team.ui.auth.LoginScreen
import `in`.newsdarpan.team.ui.dashboard.DashboardScreen
import `in`.newsdarpan.team.ui.editor.EditorQueueScreen
import `in`.newsdarpan.team.ui.media.VideoGenerationScreen
import `in`.newsdarpan.team.ui.settings.SettingsScreen
import `in`.newsdarpan.team.ui.story.CreateStoryScreen
import `in`.newsdarpan.team.ui.story.StoryDetailScreen

/**
 * Navigation route definitions for the team app.
 */
object Routes {
    const val LOGIN = "login"
    const val DASHBOARD = "dashboard"
    const val CREATE_STORY = "create_story"
    const val EDIT_STORY = "edit_story/{storyId}"
    const val STORY_DETAIL = "story_detail/{storyId}"
    const val EDITOR_QUEUE = "editor_queue"
    const val ADMIN = "admin"
    const val REPORTER_ROSTER = "reporter_roster"
    const val AUDIT_LOG = "audit_log"
    const val VIDEO_GENERATION = "video_generation/{storyId}"
    const val SETTINGS = "settings"

    fun editStory(storyId: Long) = "edit_story/$storyId"
    fun storyDetail(storyId: Long) = "story_detail/$storyId"
    fun videoGeneration(storyId: Long) = "video_generation/$storyId"
}

@Composable
fun TeamNavGraph(
    navController: NavHostController,
    startDestination: String
) {
    NavHost(
        navController = navController,
        startDestination = startDestination
    ) {
        composable(Routes.LOGIN) {
            LoginScreen(
                onLoginSuccess = {
                    navController.navigate(Routes.DASHBOARD) {
                        popUpTo(Routes.LOGIN) { inclusive = true }
                    }
                }
            )
        }

        composable(Routes.DASHBOARD) {
            DashboardScreen(
                onCreateStory = { navController.navigate(Routes.CREATE_STORY) },
                onStoryClick = { storyId -> navController.navigate(Routes.storyDetail(storyId)) },
                onEditorQueue = { navController.navigate(Routes.EDITOR_QUEUE) },
                onAdmin = { navController.navigate(Routes.ADMIN) },
                onSettings = { navController.navigate(Routes.SETTINGS) }
            )
        }

        composable(Routes.CREATE_STORY) {
            CreateStoryScreen(
                storyId = null,
                onNavigateBack = { navController.popBackStack() },
                onStorySaved = { storyId ->
                    navController.navigate(Routes.storyDetail(storyId)) {
                        popUpTo(Routes.DASHBOARD)
                    }
                }
            )
        }

        composable(
            route = Routes.EDIT_STORY,
            arguments = listOf(navArgument("storyId") { type = NavType.LongType })
        ) { backStackEntry ->
            val storyId = backStackEntry.arguments?.getLong("storyId") ?: return@composable
            CreateStoryScreen(
                storyId = storyId,
                onNavigateBack = { navController.popBackStack() },
                onStorySaved = { navController.popBackStack() }
            )
        }

        composable(
            route = Routes.STORY_DETAIL,
            arguments = listOf(navArgument("storyId") { type = NavType.LongType })
        ) { backStackEntry ->
            val storyId = backStackEntry.arguments?.getLong("storyId") ?: return@composable
            StoryDetailScreen(
                storyId = storyId,
                onNavigateBack = { navController.popBackStack() },
                onEditStory = { navController.navigate(Routes.editStory(storyId)) },
                onGenerateVideo = { navController.navigate(Routes.videoGeneration(storyId)) }
            )
        }

        composable(Routes.EDITOR_QUEUE) {
            EditorQueueScreen(
                onNavigateBack = { navController.popBackStack() },
                onStoryClick = { storyId -> navController.navigate(Routes.storyDetail(storyId)) }
            )
        }

        composable(Routes.ADMIN) {
            AdminScreen(
                onNavigateBack = { navController.popBackStack() },
                onReporterRoster = { navController.navigate(Routes.REPORTER_ROSTER) },
                onAuditLog = { navController.navigate(Routes.AUDIT_LOG) }
            )
        }

        composable(Routes.REPORTER_ROSTER) {
            ReporterRosterScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(Routes.AUDIT_LOG) {
            AuditLogScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(
            route = Routes.VIDEO_GENERATION,
            arguments = listOf(navArgument("storyId") { type = NavType.LongType })
        ) { backStackEntry ->
            val storyId = backStackEntry.arguments?.getLong("storyId") ?: return@composable
            VideoGenerationScreen(
                storyId = storyId,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(Routes.SETTINGS) {
            SettingsScreen(
                onNavigateBack = { navController.popBackStack() },
                onLogout = {
                    navController.navigate(Routes.LOGIN) {
                        popUpTo(0) { inclusive = true }
                    }
                }
            )
        }
    }
}

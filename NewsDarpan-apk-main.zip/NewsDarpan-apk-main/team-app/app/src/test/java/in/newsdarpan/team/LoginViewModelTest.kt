package `in`.newsdarpan.team

import `in`.newsdarpan.team.domain.model.*
import `in`.newsdarpan.team.domain.usecase.LoginUseCase
import `in`.newsdarpan.team.ui.auth.LoginViewModel
import `in`.newsdarpan.team.util.Result
import io.mockk.coEvery
import io.mockk.mockk
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.*
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class LoginViewModelTest {

    private val loginUseCase: LoginUseCase = mockk()
    private lateinit var viewModel: LoginViewModel
    private val testDispatcher = UnconfinedTestDispatcher()

    @Before
    fun setup() {
        Dispatchers.setMain(testDispatcher)
        viewModel = LoginViewModel(loginUseCase)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun `initial state is empty`() {
        val state = viewModel.uiState.value
        assertEquals("", state.email)
        assertEquals("", state.password)
        assertFalse(state.isLoading)
        assertNull(state.error)
        assertFalse(state.isLoggedIn)
    }

    @Test
    fun `email and password changes update state`() {
        viewModel.onEmailChange("test@newsdarpan.in")
        viewModel.onPasswordChange("password123")

        val state = viewModel.uiState.value
        assertEquals("test@newsdarpan.in", state.email)
        assertEquals("password123", state.password)
    }

    @Test
    fun `login with blank email shows error`() = runTest {
        viewModel.onEmailChange("")
        viewModel.onPasswordChange("password")
        viewModel.login()

        val state = viewModel.uiState.value
        assertNotNull(state.error)
    }

    @Test
    fun `successful login sets isLoggedIn to true`() = runTest {
        val mockUser = User(
            id = 1,
            email = "admin@newsdarpan.in",
            fullName = "Admin User",
            role = UserRole.SUPER_ADMIN,
            capabilities = Capability.entries
        )

        coEvery { loginUseCase(any(), any()) } returns Result.Success(mockUser)

        viewModel.onEmailChange("admin@newsdarpan.in")
        viewModel.onPasswordChange("password123")
        viewModel.login()

        val state = viewModel.uiState.value
        assertTrue(state.isLoggedIn)
        assertNull(state.error)
    }

    @Test
    fun `failed login shows error message`() = runTest {
        coEvery { loginUseCase(any(), any()) } returns Result.Error("Invalid email or password")

        viewModel.onEmailChange("wrong@email.com")
        viewModel.onPasswordChange("wrongpassword")
        viewModel.login()

        val state = viewModel.uiState.value
        assertFalse(state.isLoggedIn)
        assertEquals("Invalid email or password", state.error)
    }
}

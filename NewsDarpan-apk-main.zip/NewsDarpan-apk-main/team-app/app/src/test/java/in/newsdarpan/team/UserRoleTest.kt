package `in`.newsdarpan.team

import `in`.newsdarpan.team.domain.model.*
import org.junit.Assert.*
import org.junit.Test

/**
 * Tests for role-based capability assignment.
 * Verifies that:
 * - Field reporters can only create/upload content
 * - Editors and Administrators can generate videos
 * - Super admins have all capabilities
 */
class UserRoleTest {

    @Test
    fun `field reporter has only content creation capabilities`() {
        val capabilities = UserRole.FIELD_REPORTER.defaultCapabilities()
        assertTrue(capabilities.contains(Capability.CREATE_STORY))
        assertTrue(capabilities.contains(Capability.EDIT_OWN_STORY))
        assertTrue(capabilities.contains(Capability.UPLOAD_MEDIA))
        assertFalse(capabilities.contains(Capability.REVIEW_STORIES))
        assertFalse(capabilities.contains(Capability.APPROVE_STORIES))
        assertFalse(capabilities.contains(Capability.PUBLISH_STORIES))
        assertFalse(capabilities.contains(Capability.GENERATE_VIDEO))
        assertFalse(capabilities.contains(Capability.MANAGE_REPORTERS))
    }

    @Test
    fun `editor can generate video`() {
        val capabilities = UserRole.EDITOR.defaultCapabilities()
        assertTrue(capabilities.contains(Capability.GENERATE_VIDEO))
        assertTrue(capabilities.contains(Capability.REVIEW_STORIES))
        assertTrue(capabilities.contains(Capability.APPROVE_STORIES))
        assertTrue(capabilities.contains(Capability.PUBLISH_STORIES))
    }

    @Test
    fun `administrator can generate video`() {
        val capabilities = UserRole.ADMINISTRATOR.defaultCapabilities()
        assertTrue(capabilities.contains(Capability.GENERATE_VIDEO))
        assertTrue(capabilities.contains(Capability.MANAGE_REPORTERS))
        assertTrue(capabilities.contains(Capability.VIEW_AUDIT_LOG))
    }

    @Test
    fun `desk reporter cannot generate video`() {
        val capabilities = UserRole.DESK_REPORTER.defaultCapabilities()
        assertFalse(capabilities.contains(Capability.GENERATE_VIDEO))
    }

    @Test
    fun `sub editor cannot generate video`() {
        val capabilities = UserRole.SUB_EDITOR.defaultCapabilities()
        assertFalse(capabilities.contains(Capability.GENERATE_VIDEO))
    }

    @Test
    fun `super admin has all capabilities`() {
        val capabilities = UserRole.SUPER_ADMIN.defaultCapabilities()
        assertEquals(Capability.entries.toSet(), capabilities)
    }

    @Test
    fun `role hierarchy levels are correct`() {
        assertTrue(UserRole.SUPER_ADMIN.level > UserRole.ADMINISTRATOR.level)
        assertTrue(UserRole.ADMINISTRATOR.level > UserRole.EDITOR.level)
        assertTrue(UserRole.EDITOR.level > UserRole.SUB_EDITOR.level)
        assertTrue(UserRole.SUB_EDITOR.level > UserRole.DESK_REPORTER.level)
        assertTrue(UserRole.DESK_REPORTER.level > UserRole.FIELD_REPORTER.level)
    }

    @Test
    fun `role fromString handles various formats`() {
        assertEquals(UserRole.FIELD_REPORTER, UserRole.fromString("FIELD_REPORTER"))
        assertEquals(UserRole.FIELD_REPORTER, UserRole.fromString("field_reporter"))
        assertEquals(UserRole.SUPER_ADMIN, UserRole.fromString("SUPER_ADMIN"))
    }
}

# NewsDarpan Team App

Internal Android application for the NewsDarpan editorial team. Only users registered on the [NewsDarpan Cockpit](https://newsdarpan.in/cockpit/) can access this app.

## Architecture

- **Language:** Kotlin
- **UI:** Jetpack Compose + Material 3
- **DI:** Hilt
- **Network:** Retrofit + OkHttp + Kotlinx Serialization
- **Local Storage:** Room (offline drafts) + DataStore (preferences/tokens)
- **Offline Sync:** WorkManager
- **Navigation:** Jetpack Navigation Compose
- **Image Loading:** Coil

## Role-Based Access

The app enforces role-based access. Each user's capabilities determine which features are visible and accessible:

| Role | Content | Review | Publish | Video Generation | Admin |
|------|---------|--------|---------|-----------------|-------|
| Field Reporter | Create, Upload | - | - | - | - |
| Desk Reporter | Create, Upload | - | - | - | - |
| Sub Editor | Create, Upload | Review | - | - | - |
| Editor | Create, Upload | Review, Approve, Reject | Publish | Yes | - |
| Legal Reviewer | - | Review, Approve, Reject | - | - | - |
| Administrator | Create, Upload | Review, Approve, Reject | Publish | Yes | Full |
| Super Admin | All | All | All | Yes | All |

**Important:** Video generation is only available to Editor and Administrator (and Super Admin) roles.

## API Endpoints

- **Auth:** `POST https://newsdarpan.in/api/v1/auth/token/` (JWT)
- **Staff API:** `https://newsdarpan.in/api/staff/v1/` (all team operations)

## Project Structure

```
app/src/main/java/in/newsdarpan/team/
  ├── TeamApplication.kt          # Hilt Application
  ├── di/                         # Dependency Injection modules
  ├── data/
  │   ├── api/                    # Retrofit API interfaces
  │   ├── local/                  # Room DB, DataStore TokenManager
  │   ├── model/                  # DTOs and mappers
  │   └── repository/             # Repositories
  ├── domain/
  │   ├── model/                  # Domain models
  │   └── usecase/                # Use cases
  ├── ui/
  │   ├── auth/                   # Login screen
  │   ├── dashboard/              # Dashboard
  │   ├── story/                  # Create/Edit/Detail screens
  │   ├── editor/                 # Editor review queue
  │   ├── media/                  # Video generation
  │   ├── admin/                  # Admin panel, audit log, roster
  │   ├── settings/               # Settings and logout
  │   ├── common/components/      # Shared composables
  │   ├── navigation/             # Nav graph
  │   └── theme/                  # Material 3 theme
  └── util/                       # Utilities, Result, Workers
```

## Building

Open `team-app/` in Android Studio as the project root. The project uses:

- **Gradle 8.9** (wrapper included)
- **AGP 8.7.3**
- **Kotlin 2.1.0**
- **compileSdk 35, minSdk 26, targetSdk 35**

```bash
./gradlew assembleDebug
```

## Security

- No cleartext traffic allowed (HTTPS only)
- JWT tokens stored via DataStore (consider migration to EncryptedSharedPreferences for production)
- Backup disabled for security
- All workflow transitions are enforced server-side (no self-approval, capability checks)
- The app never stores secret keys offline

# NewsDarpan Mobile Apps — Implementation Cross-Reference

Version: 1.0
Date: 22 July 2026
Owner: NewsDarpan

---

## 1. Why this file exists

The reader app blueprint and reporter/team app blueprint describe two distinct products.
This document maps both apps to the same live backend, highlights shared and separate APIs, data models, workflows and risks, and gives the implementation sequence.

## 2. Products at a glance

| | NewsDarpan Reader App | NewsDarpan Team App |
| Audience | General public on Android + iOS | Internal reporters, desk, editors, legal, admin |
| Platform | Android + iOS | Android only at launch |
| Recommended stack | Flutter | Kotlin + Jetpack Compose |
| Distribution | Google Play, App Store | Internal / closed track |
| Auth | Guest optional; reader account Phase 2 | Staff `accounts.User` JWT required |
| API namespace | `/api/mobile/v1/` | `/api/staff/v1/` |
| Key non-functional | Speed, offline, accessibility, shareability | Security, workflow correctness, auditability |

## 3. What is shared

### 3.1 Brand
- Canonical logo: `/home/newsdarpan/exports/website/logo-header-400x120.png`.
- Tagline: *The Digital Mirror of India*.
- Both apps must not create alternate logos.

### 3.2 Content model
- `apps.newsroom.models.Story` is the single article entity.
- `TranslationGroup` pairs EN/HI versions.
- `Section`, `Tag`, `Region` power navigation and filtering.
- `MediaAsset` stores images/videos with caption/alt/credit/AI flag.
- `SEORecord` provides title, description, schema, FAQ, key points.
- `Comment` and `LiveUpdate` are common, though staff app writes live updates and moderates comments.

### 3.3 Publishing truth
- Only `status=published` stories appear in reader app.
- Staff app works with all workflow states.
- Demotion/correction in staff app must invalidate reader caches and downloads.
- Both apps use canonical URL shape `/{lang}/article/{slug}` for sharing and deep links.

### 3.4 Backend services
- Both rely on a new set of mobile-oriented APIs.
- Reader API must be read-only for public content plus a few safe actions (comment, newsletter, device token).
- Staff API must be fully permissioned by `Capability` and write auditable transitions.

## 4. What must stay separate

| Concern | Reader app | Staff app |
| Deep link routes | Public article/author/section | Internal screens must not be web-deep-linkable publicly |
| Auth model | Reader account (Phase 2) or anonymous | Staff `User` + role |
| Push provider | FCM/APNs to reader topics | FCM to internal staff topics |
| Notifications | Breaking, sections, regions, daily briefing | Story assigned, approved/rejected, legal review, queue aging |
| Image uploads | None | Capture/upload with caption/alt/AI flag |
| Workflow write | None | Transitions, live updates, corrections, comments moderation |
| Search scope | Published only | All states, including drafts/rejected/legal |
| Comments | Read/submit as guest/account | Moderate |
| SEO fields | Read-only | Read and edit inline |

## 5. Data flow diagram (simplified)

```
Django NDSAAS
  ├── public site (HTML)              ──→ search engines, Google News, Discover
  ├── /api/mobile/v1/                 ──→ Reader app (Android + iOS)
  └── /api/staff/v1/                  ──→ Reporter/Team app (Android)
```

Important: the staff app must never send a story directly to the public reader API. It always uses the workflow service; the reader API reads only `published` rows.

## 6. Shared backend implementation plan

Create two new Django apps to avoid polluting existing public templates and staff cockpit:
- `apps.mobile_api` — public reader endpoints.
- `apps.staff_api` — authenticated team endpoints.

Shared building blocks:
- Reusable serializers for story summary, story detail, author, section, region, media, SEO and comment.
- A `BodyBlockConverter` that emits structured blocks for native renderers while keeping sanitized HTML available.
- Cursor pagination helper.
- Mobile device/token model (`MobileInstallation`) supporting FCM/APNs and internal staff tokens.
- Notification campaign/audit model.
- Correction/tombstone and content revision API used by both apps.
- OpenAPI schema and generated clients.

## 7. API separation and security

Reader API:
- `AllowAny` for read endpoints; rate-limited by anon/user scopes.
- No staff fields exposed: no `status`, `risk_tier`, `legal_hold`, `quality_breakdown`, `origin_candidates`, editor notes, workflow decisions.
- Comment and newsletter endpoints require light abuse controls.

Staff API:
- `IsAuthenticated` + `HasCapability` on every write.
- Story-level permission checks: owner-edit, capability-edit, no self-approval.
- Never allow a reporter to call publish or approve.
- `OVERRIDE_POLICY` capability is for emergency use only and must be heavily logged.

## 8. Cache invalidation contract

Both apps need a content revision mechanism:
- Each published story carries a content revision or `updated_at` timestamp.
- Reader app polls revision on story open and reconciles local/downloaded content.
- Staff demotion or correction bumps revision and emits a tombstone.
- Staff app corrections trigger public cache bump via existing `bump_cache_version` on backend.

## 9. Deep links and web parity

Reader app deep links must be public web routes:
- `https://newsdarpan.in/hi/article/{slug}`
- `https://newsdarpan.in/en/article/{slug}`
- `https://newsdarpan.in/section/{slug}/`
- `https://newsdarpan.in/author/{slug}/`

Staff app must not claim public web routes for internal-only screens. Use custom internal scheme or private app links that do not conflict with website URLs.

## 10. Analytics and privacy separation

Reader analytics:
- Focus on readership, engagement, search, shares, notifications.

Staff analytics:
- Focus on throughput, queue age, correction rate, quality/SEO gate pass/fail, reporter contribution.
- No staff analytics must leak to public analytics providers.

## 11. Notification channels

Reader push topics:
- `reader-breaking-{lang}`
- `reader-section-{slug}-{lang}`
- `reader-region-{slug}-{lang}`
- `reader-daily-{lang}`

Staff push topics:
- `staff-story-assigned-{userId}`
- `staff-approval-feedback-{userId}`
- `staff-legal-review`
- `staff-queue-aging`

Same FCM project can host both; separate server-side campaign models and delivery workers.

## 12. Recommended implementation order

1. Backend: OpenAPI contract for mobile reader + staff APIs.
2. Backend: implement `/api/mobile/v1/bootstrap`, `/stories`, `/story/{id}`, `/search`, `/authors`, `/pages` and device token endpoint.
3. Backend: implement `/api/staff/v1/me`, `/stories` CRUD, `/stories/{id}/media`, transitions, `/reporters`, `/audit`.
4. Reader app: home, sections, article, search, saved, deep links, offline, analytics.
5. Team app: login, dashboard, create story, media upload, submit for review, offline draft sync.
6. Team app: editor queue, transitions, SEO/quality card, bilingual pair, comments moderation.
7. Team app: admin reporter roster, audit log, notifications, settings.
8. Both: notification backend, correction/tombstone handling, security/performance hardening.
9. Store/internal rollout.

## 13. Risks and mitigations

| Risk | Mitigation |
| Staff bypasses workflow through app | All transitions call the same backend service; enforce capabilities server-side, not client-side. |
| Self-approval in mobile | Backend `story.author_id == actor.pk` check in `WorkflowError`. |
| AI image on sensitive event | Backend policy gates; app shows `is_ai_generated` and rejects sensitive generation. |
| Hindi/English language leak | Client script indicators; server `_language_mismatch` check at publish. |
| Draft loss in field | Local persistence + WorkManager upload retry + conflict UI. |
| Internal content leaks to reader | Reader API filters `status=published` and never includes staff fields. |
| Demoted story remains cached | Content revision + tombstone reconciliation in both apps. |
| Root/jailbroken device exfiltration | Internal-only distribution, advisory checks, no offline storage of secret keys, remote wipe via MDM. |

## 14. Definition of done for the combined project

- Reader app and Team app exist in separate codebases.
- Both apps consume versioned APIs and never access each other’s namespace.
- Website canonical URLs, SEO, Google News and Discover signals are unchanged or improved.
- All publish transitions are audited and gated server-side.
- Reader app only shows published content and handles corrections/demotions.
- Team app supports reporter, desk, editor, legal and admin roles without capability leaks.
- Both pass security, privacy, store/enterprise distribution and accessibility acceptance.

## 15. Source-of-truth file map

- `/home/newsdarpan/projects/NDSAAS/00_RULEBOOK.md`
- `/home/newsdarpan/projects/NDSAAS/01_BLUEPRINT.md`
- `/home/newsdarpan/projects/NDSAAS/apps/newsroom/models.py`
- `/home/newsdarpan/projects/NDSAAS/apps/accounts/models.py`
- `/home/newsdarpan/projects/NDSAAS/apps/accounts/roles.py`
- `/home/newsdarpan/projects/NDSAAS/apps/workflow/services.py`
- `/home/newsdarpan/projects/NDSAAS/apps/workflow/policy.py`
- `/home/newsdarpan/projects/NDSAAS/apps/publishing/views.py`
- `/home/newsdarpan/projects/NDSAAS/apps/sources/submissions.py`

End of cross-reference.
